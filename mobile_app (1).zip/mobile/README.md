# MyJantes Mobile App

Application mobile React Native (Expo) pour MyJantes - compatible iOS et Android via Expo Go.

## Prérequis

- Node.js 18+
- Expo CLI
- Expo Go app sur votre téléphone (iOS ou Android)

## Installation

```bash
cd mobile
npm install
```

## Configuration

1. Copiez l'URL de votre backend Replit
2. Modifiez le fichier `app.json` pour définir `extra.apiUrl` avec votre URL
3. Ou définissez la variable d'environnement `EXPO_PUBLIC_API_URL`

## Lancement

```bash
# Démarrer le serveur de développement Expo
npx expo start

# Ou avec tunnel pour accès distant
npx expo start --tunnel
```

Scannez le QR code avec l'app Expo Go sur votre téléphone.

## Fonctionnalités

### Portail Client
- Tableau de bord avec résumé des devis, factures et réservations
- Consultation des devis
- Suivi des factures
- Gestion des réservations
- Paramètres du profil

### Portail Administrateur
- Tableau de bord avec statistiques
- Gestion complète des devis
- Gestion des factures
- Gestion des réservations
- Chat interne
- Paramètres de l'application

## Structure du projet

```
mobile/
├── App.tsx                    # Point d'entrée
├── app.json                   # Configuration Expo
├── package.json               # Dépendances
├── src/
│   ├── components/            # Composants réutilisables
│   │   ├── Badge.tsx
│   │   ├── Button.tsx
│   │   ├── Card.tsx
│   │   ├── Input.tsx
│   │   └── LoadingScreen.tsx
│   ├── contexts/              # Contextes React
│   │   ├── AuthContext.tsx    # Authentification
│   │   └── ThemeContext.tsx   # Thème clair/sombre
│   ├── hooks/                 # Hooks personnalisés
│   ├── lib/                   # Utilitaires
│   │   ├── api.ts             # Client API
│   │   └── queryClient.ts     # Configuration TanStack Query
│   ├── navigation/            # Navigation React Navigation
│   │   ├── AuthNavigator.tsx
│   │   ├── AdminNavigator.tsx
│   │   ├── ClientNavigator.tsx
│   │   └── RootNavigator.tsx
│   ├── screens/               # Écrans de l'application
│   │   ├── auth/
│   │   ├── admin/
│   │   ├── client/
│   │   └── shared/
│   └── types/                 # Types TypeScript
│       └── schema.ts
└── assets/                    # Assets (icônes, images)
```

## Authentification

L'application utilise un système d'authentification par token Bearer :
- Le token est stocké de manière sécurisée via `expo-secure-store`
- Les tokens expirent après 30 jours
- Le backend supporte à la fois l'authentification par session (web) et par token (mobile)

## Thème

L'application supporte le mode clair et sombre :
- Mode automatique (suit les paramètres système)
- Mode clair forcé
- Mode sombre forcé

Le choix est persisté localement sur l'appareil.

## API

L'application communique avec le même backend Express que l'application web.
Les endpoints API sont identiques, seule la méthode d'authentification diffère.

## Notes de développement

- Les erreurs LSP dans le dossier `mobile/` avant l'installation des dépendances sont normales
- Assurez-vous que le backend est accessible depuis votre appareil mobile
- Pour le développement local, utilisez `npx expo start --tunnel` pour créer un tunnel accessible
