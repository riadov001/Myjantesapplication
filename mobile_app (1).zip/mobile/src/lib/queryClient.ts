import { QueryClient } from '@tanstack/react-query';
import { fetchWithAuth } from './api';

async function defaultQueryFn({ queryKey }: { queryKey: readonly unknown[] }) {
  const endpoint = queryKey[0] as string;
  const response = await fetchWithAuth(endpoint);
  
  if (!response.ok) {
    if (response.status === 401) {
      throw new Error('Unauthorized');
    }
    throw new Error(`API error: ${response.status}`);
  }
  
  return response.json();
}

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: defaultQueryFn,
      staleTime: 1000 * 60 * 5,
      retry: (failureCount, error) => {
        if (error instanceof Error && error.message === 'Unauthorized') {
          return false;
        }
        return failureCount < 3;
      },
    },
  },
});
