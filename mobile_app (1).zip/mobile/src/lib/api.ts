import * as SecureStore from 'expo-secure-store';

// Use EXPO_PUBLIC_API_URL env var, or fallback to Replit URL for production
const getApiUrl = () => {
  if (process.env.EXPO_PUBLIC_API_URL) {
    return process.env.EXPO_PUBLIC_API_URL;
  }
  // Default to the Replit app URL (production)
  return 'https://workspace.appmytools.replit.app';
};

const API_URL = getApiUrl();

let authToken: string | null = null;

export async function getAuthToken(): Promise<string | null> {
  if (authToken) return authToken;
  try {
    authToken = await SecureStore.getItemAsync('authToken');
    return authToken;
  } catch {
    return null;
  }
}

export async function setAuthToken(token: string): Promise<void> {
  authToken = token;
  await SecureStore.setItemAsync('authToken', token);
}

export async function clearAuthToken(): Promise<void> {
  authToken = null;
  await SecureStore.deleteItemAsync('authToken');
}

export async function apiRequest<T>(
  method: 'GET' | 'POST' | 'PATCH' | 'DELETE',
  endpoint: string,
  data?: unknown
): Promise<T> {
  const token = await getAuthToken();
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    'X-Mobile-App': 'true',
  };
  
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const config: RequestInit = {
    method,
    headers,
  };

  if (data && method !== 'GET') {
    // Add mobile flag to body for login/register
    const bodyData = endpoint === '/api/login' || endpoint === '/api/register' 
      ? { ...data as object, mobile: true }
      : data;
    config.body = JSON.stringify(bodyData);
  }

  const response = await fetch(`${API_URL}${endpoint}`, config);

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ message: 'Request failed' }));
    throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
  }

  if (response.status === 204) {
    return {} as T;
  }

  return response.json();
}

export async function fetchWithAuth(endpoint: string): Promise<Response> {
  const token = await getAuthToken();
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    'X-Mobile-App': 'true',
  };
  
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  return fetch(`${API_URL}${endpoint}`, { headers });
}

export { API_URL };
