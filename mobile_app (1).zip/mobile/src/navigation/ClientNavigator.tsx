import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/contexts/ThemeContext';
import { ClientDashboardScreen } from '@/screens/client/ClientDashboardScreen';
import { QuotesListScreen } from '@/screens/shared/QuotesListScreen';
import { QuoteDetailScreen } from '@/screens/shared/QuoteDetailScreen';
import { InvoicesListScreen } from '@/screens/shared/InvoicesListScreen';
import { InvoiceDetailScreen } from '@/screens/shared/InvoiceDetailScreen';
import { ReservationsListScreen } from '@/screens/shared/ReservationsListScreen';
import { ReservationDetailScreen } from '@/screens/shared/ReservationDetailScreen';
import { NotificationsScreen } from '@/screens/shared/NotificationsScreen';
import { SettingsScreen } from '@/screens/shared/SettingsScreen';
import { useQuery } from '@tanstack/react-query';
import type { Notification } from '@/types/schema';
import { View, Text, StyleSheet } from 'react-native';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

function NotificationBadge() {
  const { colors } = useTheme();
  const { data: notifications } = useQuery<Notification[]>({
    queryKey: ['/api/notifications'],
  });
  
  const unreadCount = notifications?.filter(n => !n.isRead).length || 0;
  
  if (unreadCount === 0) return null;
  
  return (
    <View style={[styles.badge, { backgroundColor: colors.destructive }]}>
      <Text style={styles.badgeText}>{unreadCount > 9 ? '9+' : unreadCount}</Text>
    </View>
  );
}

function DashboardStack() {
  const { colors } = useTheme();

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: colors.card },
        headerTintColor: colors.text,
        headerTitleStyle: { fontWeight: '600' },
      }}
    >
      <Stack.Screen
        name="ClientDashboard"
        component={ClientDashboardScreen}
        options={({ navigation }) => ({
          title: 'Tableau de bord',
          headerRight: () => (
            <TouchableOpacity
              onPress={() => navigation.navigate('Notifications')}
              style={styles.headerButton}
            >
              <Ionicons name="notifications-outline" size={24} color={colors.text} />
              <NotificationBadge />
            </TouchableOpacity>
          ),
        })}
      />
      <Stack.Screen
        name="Notifications"
        component={NotificationsScreen}
        options={{ title: 'Notifications' }}
      />
      <Stack.Screen
        name="QuoteDetail"
        component={QuoteDetailScreen}
        options={{ title: 'Détails du devis' }}
      />
      <Stack.Screen
        name="InvoiceDetail"
        component={InvoiceDetailScreen}
        options={{ title: 'Détails de la facture' }}
      />
      <Stack.Screen
        name="ReservationDetail"
        component={ReservationDetailScreen}
        options={{ title: 'Détails de la réservation' }}
      />
    </Stack.Navigator>
  );
}

function QuotesStack() {
  const { colors } = useTheme();

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: colors.card },
        headerTintColor: colors.text,
        headerTitleStyle: { fontWeight: '600' },
      }}
    >
      <Stack.Screen
        name="QuotesList"
        component={QuotesListScreen}
        options={{ title: 'Mes devis' }}
      />
      <Stack.Screen
        name="QuoteDetail"
        component={QuoteDetailScreen}
        options={{ title: 'Détails du devis' }}
      />
    </Stack.Navigator>
  );
}

function InvoicesStack() {
  const { colors } = useTheme();

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: colors.card },
        headerTintColor: colors.text,
        headerTitleStyle: { fontWeight: '600' },
      }}
    >
      <Stack.Screen
        name="InvoicesList"
        component={InvoicesListScreen}
        options={{ title: 'Mes factures' }}
      />
      <Stack.Screen
        name="InvoiceDetail"
        component={InvoiceDetailScreen}
        options={{ title: 'Détails de la facture' }}
      />
    </Stack.Navigator>
  );
}

function ReservationsStack() {
  const { colors } = useTheme();

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: colors.card },
        headerTintColor: colors.text,
        headerTitleStyle: { fontWeight: '600' },
      }}
    >
      <Stack.Screen
        name="ReservationsList"
        component={ReservationsListScreen}
        options={{ title: 'Mes réservations' }}
      />
      <Stack.Screen
        name="ReservationDetail"
        component={ReservationDetailScreen}
        options={{ title: 'Détails' }}
      />
    </Stack.Navigator>
  );
}

function SettingsStack() {
  const { colors } = useTheme();

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: colors.card },
        headerTintColor: colors.text,
        headerTitleStyle: { fontWeight: '600' },
      }}
    >
      <Stack.Screen
        name="SettingsMain"
        component={SettingsScreen}
        options={{ title: 'Paramètres' }}
      />
    </Stack.Navigator>
  );
}

export function ClientNavigator() {
  const { colors } = useTheme();

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: {
          backgroundColor: colors.card,
          borderTopColor: colors.border,
        },
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textTertiary,
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: keyof typeof Ionicons.glyphMap;

          switch (route.name) {
            case 'Home':
              iconName = focused ? 'home' : 'home-outline';
              break;
            case 'Quotes':
              iconName = focused ? 'document-text' : 'document-text-outline';
              break;
            case 'Invoices':
              iconName = focused ? 'receipt' : 'receipt-outline';
              break;
            case 'Reservations':
              iconName = focused ? 'calendar' : 'calendar-outline';
              break;
            case 'Settings':
              iconName = focused ? 'settings' : 'settings-outline';
              break;
            default:
              iconName = 'ellipse';
          }

          return <Ionicons name={iconName} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Home" component={DashboardStack} options={{ title: 'Accueil' }} />
      <Tab.Screen name="Quotes" component={QuotesStack} options={{ title: 'Devis' }} />
      <Tab.Screen name="Invoices" component={InvoicesStack} options={{ title: 'Factures' }} />
      <Tab.Screen name="Reservations" component={ReservationsStack} options={{ title: 'RDV' }} />
      <Tab.Screen name="Settings" component={SettingsStack} options={{ title: 'Paramètres' }} />
    </Tab.Navigator>
  );
}

const styles = StyleSheet.create({
  headerButton: {
    padding: 8,
    marginRight: 8,
    position: 'relative',
  },
  badge: {
    position: 'absolute',
    top: 2,
    right: 2,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: 'bold',
  },
});
