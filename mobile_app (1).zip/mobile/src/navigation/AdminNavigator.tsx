import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { TouchableOpacity, View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/contexts/ThemeContext';
import { useQuery } from '@tanstack/react-query';
import { AdminDashboardScreen } from '@/screens/admin/AdminDashboardScreen';
import { QuotesListScreen } from '@/screens/shared/QuotesListScreen';
import { QuoteDetailScreen } from '@/screens/shared/QuoteDetailScreen';
import { InvoicesListScreen } from '@/screens/shared/InvoicesListScreen';
import { InvoiceDetailScreen } from '@/screens/shared/InvoiceDetailScreen';
import { ReservationsListScreen } from '@/screens/shared/ReservationsListScreen';
import { ReservationDetailScreen } from '@/screens/shared/ReservationDetailScreen';
import { NewReservationScreen } from '@/screens/shared/NewReservationScreen';
import { NotificationsScreen } from '@/screens/shared/NotificationsScreen';
import { UsersListScreen } from '@/screens/admin/UsersListScreen';
import { ServicesListScreen } from '@/screens/admin/ServicesListScreen';
import { ChatListScreen, ChatConversationScreen } from '@/screens/shared/ChatScreen';
import { SettingsScreen } from '@/screens/shared/SettingsScreen';
import type { Notification } from '@/types/schema';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

function NotificationBadge() {
  const { colors } = useTheme();
  const { data: notifications } = useQuery<Notification[]>({
    queryKey: ['/api/notifications'],
  });
  
  const unreadCount = notifications?.filter(n => !n.isRead).length || 0;
  
  if (unreadCount === 0) return null;
  
  return (
    <View style={[styles.badge, { backgroundColor: colors.destructive }]}>
      <Text style={styles.badgeText}>{unreadCount > 9 ? '9+' : unreadCount}</Text>
    </View>
  );
}

function DashboardStack() {
  const { colors } = useTheme();

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: colors.card },
        headerTintColor: colors.text,
        headerTitleStyle: { fontWeight: '600' },
      }}
    >
      <Stack.Screen
        name="AdminDashboard"
        component={AdminDashboardScreen}
        options={({ navigation }) => ({
          title: 'Tableau de bord',
          headerRight: () => (
            <TouchableOpacity
              onPress={() => navigation.navigate('Notifications')}
              style={styles.headerButton}
            >
              <Ionicons name="notifications-outline" size={24} color={colors.text} />
              <NotificationBadge />
            </TouchableOpacity>
          ),
        })}
      />
      <Stack.Screen name="Notifications" component={NotificationsScreen} options={{ title: 'Notifications' }} />
      <Stack.Screen name="Engagements" component={QuotesListScreen} options={{ title: 'Prestations' }} />
      <Stack.Screen name="Workshop" component={ReservationsListScreen} options={{ title: 'Atelier' }} />
      <Stack.Screen name="Quotes" component={QuotesListScreen} options={{ title: 'Devis' }} />
      <Stack.Screen name="Invoices" component={InvoicesListScreen} options={{ title: 'Factures' }} />
      <Stack.Screen name="Reservations" component={ReservationsListScreen} options={{ title: 'Réservations' }} />
      <Stack.Screen name="NewReservation" component={NewReservationScreen} options={{ title: 'Nouvelle réservation' }} />
      <Stack.Screen name="Services" component={ServicesListScreen} options={{ title: 'Services' }} />
      <Stack.Screen name="Users" component={UsersListScreen} options={{ title: 'Utilisateurs' }} />
      <Stack.Screen name="Chat" component={ChatListScreen} options={{ title: 'Chat interne' }} />
      <Stack.Screen name="QuoteDetail" component={QuoteDetailScreen} options={{ title: 'Détails du devis' }} />
      <Stack.Screen name="InvoiceDetail" component={InvoiceDetailScreen} options={{ title: 'Détails de la facture' }} />
      <Stack.Screen name="ReservationDetail" component={ReservationDetailScreen} options={{ title: 'Détails' }} />
    </Stack.Navigator>
  );
}

function QuotesStack() {
  const { colors } = useTheme();

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: colors.card },
        headerTintColor: colors.text,
        headerTitleStyle: { fontWeight: '600' },
      }}
    >
      <Stack.Screen name="QuotesList" component={QuotesListScreen} options={{ title: 'Devis' }} />
      <Stack.Screen name="QuoteDetail" component={QuoteDetailScreen} options={{ title: 'Détails du devis' }} />
    </Stack.Navigator>
  );
}

function InvoicesStack() {
  const { colors } = useTheme();

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: colors.card },
        headerTintColor: colors.text,
        headerTitleStyle: { fontWeight: '600' },
      }}
    >
      <Stack.Screen name="InvoicesList" component={InvoicesListScreen} options={{ title: 'Factures' }} />
      <Stack.Screen name="InvoiceDetail" component={InvoiceDetailScreen} options={{ title: 'Détails' }} />
    </Stack.Navigator>
  );
}

function ChatStack() {
  const { colors } = useTheme();

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: colors.card },
        headerTintColor: colors.text,
        headerTitleStyle: { fontWeight: '600' },
      }}
    >
      <Stack.Screen name="ChatList" component={ChatListScreen} options={{ title: 'Chat interne' }} />
      <Stack.Screen
        name="ChatConversation"
        component={ChatConversationScreen}
        options={({ route }: any) => ({ title: route.params?.title || 'Conversation' })}
      />
    </Stack.Navigator>
  );
}

function SettingsStack() {
  const { colors } = useTheme();

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: colors.card },
        headerTintColor: colors.text,
        headerTitleStyle: { fontWeight: '600' },
      }}
    >
      <Stack.Screen name="SettingsMain" component={SettingsScreen} options={{ title: 'Paramètres' }} />
      <Stack.Screen name="AppSettings" component={SettingsScreen} options={{ title: 'Paramètres app' }} />
      <Stack.Screen name="AuditLog" component={SettingsScreen} options={{ title: "Journal d'audit" }} />
      <Stack.Screen name="EditProfile" component={SettingsScreen} options={{ title: 'Modifier le profil' }} />
    </Stack.Navigator>
  );
}

export function AdminNavigator() {
  const { colors } = useTheme();

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: {
          backgroundColor: colors.card,
          borderTopColor: colors.border,
        },
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textTertiary,
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: keyof typeof Ionicons.glyphMap;

          switch (route.name) {
            case 'Dashboard':
              iconName = focused ? 'grid' : 'grid-outline';
              break;
            case 'Quotes':
              iconName = focused ? 'document-text' : 'document-text-outline';
              break;
            case 'Invoices':
              iconName = focused ? 'receipt' : 'receipt-outline';
              break;
            case 'Chat':
              iconName = focused ? 'chatbubbles' : 'chatbubbles-outline';
              break;
            case 'Settings':
              iconName = focused ? 'settings' : 'settings-outline';
              break;
            default:
              iconName = 'ellipse';
          }

          return <Ionicons name={iconName} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Dashboard" component={DashboardStack} options={{ title: 'Accueil' }} />
      <Tab.Screen name="Quotes" component={QuotesStack} options={{ title: 'Devis' }} />
      <Tab.Screen name="Invoices" component={InvoicesStack} options={{ title: 'Factures' }} />
      <Tab.Screen name="Chat" component={ChatStack} options={{ title: 'Chat' }} />
      <Tab.Screen name="Settings" component={SettingsStack} options={{ title: 'Paramètres' }} />
    </Tab.Navigator>
  );
}

const styles = StyleSheet.create({
  headerButton: {
    padding: 8,
    marginRight: 8,
    position: 'relative',
  },
  badge: {
    position: 'absolute',
    top: 2,
    right: 2,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: 'bold',
  },
});
