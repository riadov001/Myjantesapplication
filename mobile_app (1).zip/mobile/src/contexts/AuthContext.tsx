import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest, setAuthToken, clearAuthToken, getAuthToken } from '@/lib/api';
import type { User } from '@/types/schema';

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  isAdmin: boolean;
  isClient: boolean;
  isClientPro: boolean;
  isEmployee: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (data: RegisterData) => Promise<void>;
  logout: () => Promise<void>;
}

interface RegisterData {
  email: string;
  password: string;
  firstName?: string;
  lastName?: string;
  phone?: string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    getAuthToken().then(() => setIsReady(true));
  }, []);

  const { data: user, isLoading: isQueryLoading, refetch } = useQuery<User>({
    queryKey: ['/api/auth/user'],
    enabled: isReady,
    retry: false,
    staleTime: Infinity,
  });

  const isLoading = !isReady || isQueryLoading;

  const login = async (email: string, password: string) => {
    const response = await apiRequest<{ user: User; token: string }>('POST', '/api/login', {
      email,
      password,
    });
    
    if (response.token) {
      await setAuthToken(response.token);
    }
    
    await refetch();
  };

  const register = async (data: RegisterData) => {
    const response = await apiRequest<{ user: User; token: string }>('POST', '/api/register', data);
    
    if (response.token) {
      await setAuthToken(response.token);
    }
    
    await refetch();
  };

  const logout = async () => {
    try {
      await apiRequest('POST', '/api/logout', {});
    } catch {
    }
    await clearAuthToken();
    queryClient.clear();
  };

  const isAdmin = user?.role === 'admin' || user?.role === 'employe';
  const isClient = user?.role === 'client';
  const isClientPro = user?.role === 'client_professionnel';
  const isEmployee = user?.role === 'employe';

  return (
    <AuthContext.Provider
      value={{
        user: user || null,
        isLoading,
        isAuthenticated: !!user,
        isAdmin,
        isClient,
        isClientPro,
        isEmployee,
        login,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
