import { View, Text, StyleSheet, ScrollView, RefreshControl, Alert } from 'react-native';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/Card';
import { StatusBadge } from '@/components/Badge';
import { Button } from '@/components/Button';
import { LoadingScreen } from '@/components/LoadingScreen';
import { Ionicons } from '@expo/vector-icons';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { apiRequest } from '@/lib/api';
import type { Invoice } from '@/types/schema';
import { useState } from 'react';

export function InvoiceDetailScreen({ route }: any) {
  const { id } = route.params;
  const { colors } = useTheme();
  const { isAdmin } = useAuth();
  const queryClient = useQueryClient();
  const [refreshing, setRefreshing] = useState(false);

  const { data: invoice, isLoading, refetch } = useQuery<Invoice>({
    queryKey: ['/api/invoices', id],
    queryFn: () => apiRequest('GET', `/api/invoices/${id}`),
  });

  const markAsPaidMutation = useMutation({
    mutationFn: (paymentMethod: string) => 
      apiRequest('PATCH', `/api/admin/invoices/${id}`, { status: 'paid', paymentMethod }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/invoices'] });
      queryClient.invalidateQueries({ queryKey: ['/api/invoices', id] });
      Alert.alert('Succès', 'La facture a été marquée comme payée');
    },
    onError: (error: Error) => {
      Alert.alert('Erreur', error.message);
    },
  });

  const sendEmailMutation = useMutation({
    mutationFn: () => apiRequest('POST', `/api/admin/invoices/${id}/send-email`, {}),
    onSuccess: () => {
      Alert.alert('Succès', 'La facture a été envoyée par email');
    },
    onError: (error: Error) => {
      Alert.alert('Erreur', error.message);
    },
  });

  const onRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  };

  const handleMarkAsPaid = () => {
    Alert.alert(
      'Marquer comme payée',
      'Choisissez le mode de paiement',
      [
        { text: 'Annuler', style: 'cancel' },
        { text: 'Carte', onPress: () => markAsPaidMutation.mutate('card') },
        { text: 'Virement', onPress: () => markAsPaidMutation.mutate('wire_transfer') },
        { text: 'Espèces', onPress: () => markAsPaidMutation.mutate('cash') },
      ]
    );
  };

  const getPaymentMethodLabel = (method: string) => {
    switch (method) {
      case 'cash': return 'Espèces';
      case 'wire_transfer': return 'Virement bancaire';
      case 'card': return 'Carte bancaire';
      case 'check': return 'Chèque';
      default: return method;
    }
  };

  if (isLoading) {
    return <LoadingScreen message="Chargement de la facture..." />;
  }

  if (!invoice) {
    return (
      <View style={[styles.container, styles.center, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.textSecondary }}>Facture non trouvée</Text>
      </View>
    );
  }

  const priceHT = parseFloat(invoice.priceExcludingTax || invoice.amount || '0');
  const taxRate = parseFloat(invoice.taxRate || '20');
  const taxAmount = parseFloat(invoice.taxAmount || (priceHT * taxRate / 100).toString());
  const totalTTC = parseFloat(invoice.amount);

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
      }
    >
      <View style={styles.header}>
        <View>
          <Text style={[styles.invoiceNumber, { color: colors.text }]}>
            {invoice.invoiceNumber}
          </Text>
          {invoice.createdAt && (
            <Text style={[styles.date, { color: colors.textSecondary }]}>
              {format(new Date(invoice.createdAt), "d MMMM yyyy", { locale: fr })}
            </Text>
          )}
        </View>
        <StatusBadge status={invoice.status} size="large" />
      </View>

      {invoice.status === 'overdue' && (
        <View style={[styles.alertBox, { backgroundColor: colors.destructive + '20' }]}>
          <Ionicons name="warning" size={20} color={colors.destructive} />
          <Text style={[styles.alertText, { color: colors.destructive }]}>
            Cette facture est en retard de paiement
          </Text>
        </View>
      )}

      {invoice.client && (
        <Card style={styles.section}>
          <CardHeader>
            <CardTitle>Client</CardTitle>
          </CardHeader>
          <CardContent>
            <View style={styles.infoRow}>
              <Ionicons name="person-outline" size={18} color={colors.textSecondary} />
              <Text style={[styles.infoText, { color: colors.text }]}>
                {invoice.client.firstName} {invoice.client.lastName}
              </Text>
            </View>
            {invoice.client.email && (
              <View style={styles.infoRow}>
                <Ionicons name="mail-outline" size={18} color={colors.textSecondary} />
                <Text style={[styles.infoText, { color: colors.text }]}>{invoice.client.email}</Text>
              </View>
            )}
            {invoice.client.phone && (
              <View style={styles.infoRow}>
                <Ionicons name="call-outline" size={18} color={colors.textSecondary} />
                <Text style={[styles.infoText, { color: colors.text }]}>{invoice.client.phone}</Text>
              </View>
            )}
          </CardContent>
        </Card>
      )}

      <Card style={styles.section}>
        <CardHeader>
          <CardTitle>Détails</CardTitle>
        </CardHeader>
        <CardContent>
          {invoice.wheelCount && (
            <View style={styles.detailRow}>
              <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>Nombre de jantes</Text>
              <Text style={[styles.detailValue, { color: colors.text }]}>{invoice.wheelCount}</Text>
            </View>
          )}
          {invoice.diameter && (
            <View style={styles.detailRow}>
              <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>Diamètre</Text>
              <Text style={[styles.detailValue, { color: colors.text }]}>{invoice.diameter}"</Text>
            </View>
          )}
          <View style={styles.detailRow}>
            <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>Mode de paiement</Text>
            <Text style={[styles.detailValue, { color: colors.text }]}>
              {getPaymentMethodLabel(invoice.paymentMethod)}
            </Text>
          </View>
          {invoice.dueDate && (
            <View style={styles.detailRow}>
              <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>Échéance</Text>
              <Text style={[styles.detailValue, { color: colors.text }]}>
                {format(new Date(invoice.dueDate), "d MMMM yyyy", { locale: fr })}
              </Text>
            </View>
          )}
          {invoice.paidAt && (
            <View style={styles.detailRow}>
              <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>Payée le</Text>
              <Text style={[styles.detailValue, { color: colors.success }]}>
                {format(new Date(invoice.paidAt), "d MMMM yyyy", { locale: fr })}
              </Text>
            </View>
          )}
          {invoice.productDetails && (
            <View style={styles.detailRow}>
              <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>Détails produit</Text>
              <Text style={[styles.detailValue, { color: colors.text }]}>{invoice.productDetails}</Text>
            </View>
          )}
          {invoice.notes && (
            <View style={[styles.notesBox, { backgroundColor: colors.muted }]}>
              <Text style={[styles.notesLabel, { color: colors.textSecondary }]}>Notes</Text>
              <Text style={[styles.notesText, { color: colors.text }]}>{invoice.notes}</Text>
            </View>
          )}
        </CardContent>
      </Card>

      <Card style={styles.section}>
        <CardHeader>
          <CardTitle>Montant</CardTitle>
        </CardHeader>
        <CardContent>
          <View style={styles.priceRow}>
            <Text style={[styles.priceLabel, { color: colors.textSecondary }]}>Prix HT</Text>
            <Text style={[styles.priceValue, { color: colors.text }]}>{priceHT.toFixed(2)} €</Text>
          </View>
          <View style={styles.priceRow}>
            <Text style={[styles.priceLabel, { color: colors.textSecondary }]}>TVA ({taxRate}%)</Text>
            <Text style={[styles.priceValue, { color: colors.text }]}>{taxAmount.toFixed(2)} €</Text>
          </View>
          <View style={[styles.priceRow, styles.totalRow, { borderTopColor: colors.border }]}>
            <Text style={[styles.totalLabel, { color: colors.text }]}>Total TTC</Text>
            <Text style={[styles.totalValue, { color: colors.primary }]}>{totalTTC.toFixed(2)} €</Text>
          </View>
        </CardContent>
      </Card>

      {isAdmin && invoice.status === 'pending' && (
        <View style={styles.actions}>
          <Button 
            onPress={handleMarkAsPaid} 
            loading={markAsPaidMutation.isPending}
            style={styles.actionButton}
          >
            Marquer comme payée
          </Button>
          <Button 
            variant="outline" 
            onPress={() => sendEmailMutation.mutate()}
            loading={sendEmailMutation.isPending}
            style={styles.actionButton}
          >
            Envoyer par email
          </Button>
        </View>
      )}

      <View style={styles.bottomPadding} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  center: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    padding: 20,
  },
  invoiceNumber: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  date: {
    fontSize: 14,
    marginTop: 4,
  },
  alertBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginHorizontal: 16,
    marginBottom: 16,
    padding: 12,
    borderRadius: 8,
  },
  alertText: {
    fontSize: 14,
    fontWeight: '500',
  },
  section: {
    marginHorizontal: 16,
    marginBottom: 16,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 8,
  },
  infoText: {
    fontSize: 15,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.05)',
  },
  detailLabel: {
    fontSize: 14,
  },
  detailValue: {
    fontSize: 14,
    fontWeight: '500',
  },
  notesBox: {
    marginTop: 12,
    padding: 12,
    borderRadius: 8,
  },
  notesLabel: {
    fontSize: 12,
    marginBottom: 4,
  },
  notesText: {
    fontSize: 14,
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
  },
  priceLabel: {
    fontSize: 14,
  },
  priceValue: {
    fontSize: 14,
    fontWeight: '500',
  },
  totalRow: {
    borderTopWidth: 1,
    marginTop: 8,
    paddingTop: 12,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: '600',
  },
  totalValue: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  actions: {
    padding: 16,
    gap: 12,
  },
  actionButton: {
    marginBottom: 0,
  },
  bottomPadding: {
    height: 32,
  },
});
