import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useTheme } from '@/contexts/ThemeContext';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/Card';
import { Button } from '@/components/Button';
import { Input } from '@/components/Input';
import { LoadingScreen } from '@/components/LoadingScreen';
import { Ionicons } from '@expo/vector-icons';
import { format, addDays } from 'date-fns';
import { fr } from 'date-fns/locale';
import { apiRequest } from '@/lib/api';
import type { Service } from '@/types/schema';
import { useState } from 'react';

export function NewReservationScreen({ navigation }: any) {
  const { colors } = useTheme();
  const queryClient = useQueryClient();

  const [selectedServiceId, setSelectedServiceId] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date>(addDays(new Date(), 1));
  const [selectedTime, setSelectedTime] = useState<string>('10:00');
  const [notes, setNotes] = useState('');

  const { data: services, isLoading } = useQuery<Service[]>({
    queryKey: ['/api/services'],
  });

  const createReservationMutation = useMutation({
    mutationFn: (data: { serviceId: string; scheduledDate: string; notes?: string }) =>
      apiRequest('POST', '/api/admin/reservations', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/reservations'] });
      Alert.alert('Succès', 'Votre réservation a été créée', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    },
    onError: (error: Error) => {
      Alert.alert('Erreur', error.message);
    },
  });

  const handleSubmit = () => {
    if (!selectedServiceId) {
      Alert.alert('Erreur', 'Veuillez sélectionner un service');
      return;
    }

    const [hours, minutes] = selectedTime.split(':').map(Number);
    const scheduledDateTime = new Date(selectedDate);
    scheduledDateTime.setHours(hours, minutes, 0, 0);

    createReservationMutation.mutate({
      serviceId: selectedServiceId,
      scheduledDate: scheduledDateTime.toISOString(),
      notes: notes || undefined,
    });
  };

  if (isLoading) {
    return <LoadingScreen message="Chargement des services..." />;
  }

  const activeServices = services?.filter(s => s.isActive) || [];

  const availableTimes = [
    '08:00', '08:30', '09:00', '09:30', '10:00', '10:30',
    '11:00', '11:30', '14:00', '14:30', '15:00', '15:30',
    '16:00', '16:30', '17:00', '17:30',
  ];

  const availableDates = Array.from({ length: 14 }, (_, i) => addDays(new Date(), i + 1));

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
      <Card style={styles.section}>
        <CardHeader>
          <CardTitle>1. Choisir un service</CardTitle>
        </CardHeader>
        <CardContent>
          {activeServices.length === 0 ? (
            <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
              Aucun service disponible
            </Text>
          ) : (
            <View style={styles.servicesGrid}>
              {activeServices.map((service) => (
                <TouchableOpacity
                  key={service.id}
                  style={[
                    styles.serviceCard,
                    {
                      backgroundColor: selectedServiceId === service.id ? colors.primary + '20' : colors.muted,
                      borderColor: selectedServiceId === service.id ? colors.primary : 'transparent',
                    },
                  ]}
                  onPress={() => setSelectedServiceId(service.id)}
                >
                  <Ionicons
                    name={selectedServiceId === service.id ? 'checkmark-circle' : 'ellipse-outline'}
                    size={24}
                    color={selectedServiceId === service.id ? colors.primary : colors.textSecondary}
                  />
                  <View style={styles.serviceInfo}>
                    <Text style={[styles.serviceName, { color: colors.text }]}>{service.name}</Text>
                    {service.basePrice && (
                      <Text style={[styles.servicePrice, { color: colors.primary }]}>
                        À partir de {parseFloat(service.basePrice).toFixed(0)} €
                      </Text>
                    )}
                    {service.estimatedDuration && (
                      <Text style={[styles.serviceDuration, { color: colors.textSecondary }]}>
                        ~{service.estimatedDuration} min
                      </Text>
                    )}
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </CardContent>
      </Card>

      <Card style={styles.section}>
        <CardHeader>
          <CardTitle>2. Choisir une date</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={styles.datesRow}>
              {availableDates.map((date) => {
                const isSelected = format(date, 'yyyy-MM-dd') === format(selectedDate, 'yyyy-MM-dd');
                return (
                  <TouchableOpacity
                    key={date.toISOString()}
                    style={[
                      styles.dateCard,
                      {
                        backgroundColor: isSelected ? colors.primary : colors.muted,
                      },
                    ]}
                    onPress={() => setSelectedDate(date)}
                  >
                    <Text style={[styles.dateDayName, { color: isSelected ? '#fff' : colors.textSecondary }]}>
                      {format(date, 'EEE', { locale: fr })}
                    </Text>
                    <Text style={[styles.dateNumber, { color: isSelected ? '#fff' : colors.text }]}>
                      {format(date, 'd')}
                    </Text>
                    <Text style={[styles.dateMonth, { color: isSelected ? '#fff' : colors.textSecondary }]}>
                      {format(date, 'MMM', { locale: fr })}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </ScrollView>
        </CardContent>
      </Card>

      <Card style={styles.section}>
        <CardHeader>
          <CardTitle>3. Choisir une heure</CardTitle>
        </CardHeader>
        <CardContent>
          <View style={styles.timesGrid}>
            {availableTimes.map((time) => {
              const isSelected = time === selectedTime;
              return (
                <TouchableOpacity
                  key={time}
                  style={[
                    styles.timeCard,
                    {
                      backgroundColor: isSelected ? colors.primary : colors.muted,
                    },
                  ]}
                  onPress={() => setSelectedTime(time)}
                >
                  <Text style={[styles.timeText, { color: isSelected ? '#fff' : colors.text }]}>
                    {time}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </CardContent>
      </Card>

      <Card style={styles.section}>
        <CardHeader>
          <CardTitle>4. Notes (optionnel)</CardTitle>
        </CardHeader>
        <CardContent>
          <Input
            placeholder="Ajoutez des informations supplémentaires..."
            value={notes}
            onChangeText={setNotes}
            multiline
            numberOfLines={3}
            style={styles.notesInput}
          />
        </CardContent>
      </Card>

      <View style={styles.summary}>
        <Text style={[styles.summaryTitle, { color: colors.text }]}>Récapitulatif</Text>
        <View style={[styles.summaryBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.summaryRow}>
            <Text style={[styles.summaryLabel, { color: colors.textSecondary }]}>Service</Text>
            <Text style={[styles.summaryValue, { color: colors.text }]}>
              {activeServices.find(s => s.id === selectedServiceId)?.name || 'Non sélectionné'}
            </Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={[styles.summaryLabel, { color: colors.textSecondary }]}>Date</Text>
            <Text style={[styles.summaryValue, { color: colors.text }]}>
              {format(selectedDate, "EEEE d MMMM yyyy", { locale: fr })}
            </Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={[styles.summaryLabel, { color: colors.textSecondary }]}>Heure</Text>
            <Text style={[styles.summaryValue, { color: colors.text }]}>{selectedTime}</Text>
          </View>
        </View>
      </View>

      <View style={styles.actions}>
        <Button
          onPress={handleSubmit}
          loading={createReservationMutation.isPending}
          disabled={!selectedServiceId}
        >
          Confirmer la réservation
        </Button>
      </View>

      <View style={styles.bottomPadding} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  section: {
    marginHorizontal: 16,
    marginTop: 16,
  },
  emptyText: {
    textAlign: 'center',
    paddingVertical: 20,
  },
  servicesGrid: {
    gap: 12,
  },
  serviceCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    borderWidth: 2,
    gap: 12,
  },
  serviceInfo: {
    flex: 1,
  },
  serviceName: {
    fontSize: 16,
    fontWeight: '600',
  },
  servicePrice: {
    fontSize: 14,
    marginTop: 2,
  },
  serviceDuration: {
    fontSize: 12,
    marginTop: 2,
  },
  datesRow: {
    flexDirection: 'row',
    gap: 10,
  },
  dateCard: {
    width: 60,
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: 'center',
  },
  dateDayName: {
    fontSize: 12,
    textTransform: 'uppercase',
  },
  dateNumber: {
    fontSize: 20,
    fontWeight: 'bold',
    marginVertical: 4,
  },
  dateMonth: {
    fontSize: 12,
  },
  timesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  timeCard: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 8,
  },
  timeText: {
    fontSize: 14,
    fontWeight: '500',
  },
  notesInput: {
    minHeight: 80,
    textAlignVertical: 'top',
  },
  summary: {
    marginHorizontal: 16,
    marginTop: 24,
  },
  summaryTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 12,
  },
  summaryBox: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 16,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
  },
  summaryLabel: {
    fontSize: 14,
  },
  summaryValue: {
    fontSize: 14,
    fontWeight: '500',
  },
  actions: {
    padding: 16,
    marginTop: 8,
  },
  bottomPadding: {
    height: 32,
  },
});
