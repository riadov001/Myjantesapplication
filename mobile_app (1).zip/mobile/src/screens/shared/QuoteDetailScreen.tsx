import { View, Text, StyleSheet, ScrollView, RefreshControl, TouchableOpacity, Alert } from 'react-native';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/Card';
import { StatusBadge } from '@/components/Badge';
import { Button } from '@/components/Button';
import { LoadingScreen } from '@/components/LoadingScreen';
import { Ionicons } from '@expo/vector-icons';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { apiRequest } from '@/lib/api';
import type { Quote } from '@/types/schema';
import { useState } from 'react';

export function QuoteDetailScreen({ route, navigation }: any) {
  const { id } = route.params;
  const { colors } = useTheme();
  const { isAdmin } = useAuth();
  const queryClient = useQueryClient();
  const [refreshing, setRefreshing] = useState(false);

  const { data: quote, isLoading, refetch } = useQuery<Quote>({
    queryKey: ['/api/quotes', id],
    queryFn: () => apiRequest('GET', `/api/quotes/${id}`),
  });

  const updateStatusMutation = useMutation({
    mutationFn: (status: string) => 
      apiRequest('PATCH', isAdmin ? `/api/admin/quotes/${id}` : `/api/quotes/${id}`, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/quotes'] });
      queryClient.invalidateQueries({ queryKey: ['/api/quotes', id] });
      Alert.alert('Succès', 'Le statut du devis a été mis à jour');
    },
    onError: (error: Error) => {
      Alert.alert('Erreur', error.message);
    },
  });

  const generateInvoiceMutation = useMutation({
    mutationFn: () => apiRequest('POST', `/api/admin/quotes/${id}/generate-invoice`, {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/quotes'] });
      queryClient.invalidateQueries({ queryKey: ['/api/invoices'] });
      Alert.alert('Succès', 'La facture a été générée');
      navigation.goBack();
    },
    onError: (error: Error) => {
      Alert.alert('Erreur', error.message);
    },
  });

  const onRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  };

  const handleApprove = () => {
    Alert.alert(
      'Accepter le devis',
      'Voulez-vous vraiment accepter ce devis ?',
      [
        { text: 'Annuler', style: 'cancel' },
        { text: 'Accepter', onPress: () => updateStatusMutation.mutate('approved') },
      ]
    );
  };

  const handleReject = () => {
    Alert.alert(
      'Refuser le devis',
      'Voulez-vous vraiment refuser ce devis ?',
      [
        { text: 'Annuler', style: 'cancel' },
        { text: 'Refuser', style: 'destructive', onPress: () => updateStatusMutation.mutate('rejected') },
      ]
    );
  };

  const handleGenerateInvoice = () => {
    Alert.alert(
      'Générer une facture',
      'Voulez-vous générer une facture pour ce devis ?',
      [
        { text: 'Annuler', style: 'cancel' },
        { text: 'Générer', onPress: () => generateInvoiceMutation.mutate() },
      ]
    );
  };

  if (isLoading) {
    return <LoadingScreen message="Chargement du devis..." />;
  }

  if (!quote) {
    return (
      <View style={[styles.container, styles.center, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.textSecondary }}>Devis non trouvé</Text>
      </View>
    );
  }

  const priceHT = parseFloat(quote.priceExcludingTax || quote.quoteAmount || '0');
  const taxRate = parseFloat(quote.taxRate || '20');
  const taxAmount = parseFloat(quote.taxAmount || (priceHT * taxRate / 100).toString());
  const totalTTC = priceHT + taxAmount;

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
      }
    >
      <View style={styles.header}>
        <View>
          <Text style={[styles.reference, { color: colors.text }]}>
            {quote.reference || `Devis #${quote.id.slice(0, 8)}`}
          </Text>
          {quote.createdAt && (
            <Text style={[styles.date, { color: colors.textSecondary }]}>
              {format(new Date(quote.createdAt), "d MMMM yyyy", { locale: fr })}
            </Text>
          )}
        </View>
        <StatusBadge status={quote.status} size="large" />
      </View>

      {quote.client && (
        <Card style={styles.section}>
          <CardHeader>
            <CardTitle>Client</CardTitle>
          </CardHeader>
          <CardContent>
            <View style={styles.infoRow}>
              <Ionicons name="person-outline" size={18} color={colors.textSecondary} />
              <Text style={[styles.infoText, { color: colors.text }]}>
                {quote.client.firstName} {quote.client.lastName}
              </Text>
            </View>
            {quote.client.email && (
              <View style={styles.infoRow}>
                <Ionicons name="mail-outline" size={18} color={colors.textSecondary} />
                <Text style={[styles.infoText, { color: colors.text }]}>{quote.client.email}</Text>
              </View>
            )}
            {quote.client.phone && (
              <View style={styles.infoRow}>
                <Ionicons name="call-outline" size={18} color={colors.textSecondary} />
                <Text style={[styles.infoText, { color: colors.text }]}>{quote.client.phone}</Text>
              </View>
            )}
          </CardContent>
        </Card>
      )}

      {quote.service && (
        <Card style={styles.section}>
          <CardHeader>
            <CardTitle>Service</CardTitle>
          </CardHeader>
          <CardContent>
            <Text style={[styles.serviceName, { color: colors.text }]}>{quote.service.name}</Text>
            {quote.service.description && (
              <Text style={[styles.serviceDesc, { color: colors.textSecondary }]}>
                {quote.service.description}
              </Text>
            )}
          </CardContent>
        </Card>
      )}

      <Card style={styles.section}>
        <CardHeader>
          <CardTitle>Détails</CardTitle>
        </CardHeader>
        <CardContent>
          {quote.wheelCount && (
            <View style={styles.detailRow}>
              <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>Nombre de jantes</Text>
              <Text style={[styles.detailValue, { color: colors.text }]}>{quote.wheelCount}</Text>
            </View>
          )}
          {quote.diameter && (
            <View style={styles.detailRow}>
              <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>Diamètre</Text>
              <Text style={[styles.detailValue, { color: colors.text }]}>{quote.diameter}"</Text>
            </View>
          )}
          {quote.productDetails && (
            <View style={styles.detailRow}>
              <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>Détails produit</Text>
              <Text style={[styles.detailValue, { color: colors.text }]}>{quote.productDetails}</Text>
            </View>
          )}
          {quote.notes && (
            <View style={[styles.notesBox, { backgroundColor: colors.muted }]}>
              <Text style={[styles.notesLabel, { color: colors.textSecondary }]}>Notes</Text>
              <Text style={[styles.notesText, { color: colors.text }]}>{quote.notes}</Text>
            </View>
          )}
        </CardContent>
      </Card>

      <Card style={styles.section}>
        <CardHeader>
          <CardTitle>Montant</CardTitle>
        </CardHeader>
        <CardContent>
          <View style={styles.priceRow}>
            <Text style={[styles.priceLabel, { color: colors.textSecondary }]}>Prix HT</Text>
            <Text style={[styles.priceValue, { color: colors.text }]}>{priceHT.toFixed(2)} €</Text>
          </View>
          <View style={styles.priceRow}>
            <Text style={[styles.priceLabel, { color: colors.textSecondary }]}>TVA ({taxRate}%)</Text>
            <Text style={[styles.priceValue, { color: colors.text }]}>{taxAmount.toFixed(2)} €</Text>
          </View>
          <View style={[styles.priceRow, styles.totalRow, { borderTopColor: colors.border }]}>
            <Text style={[styles.totalLabel, { color: colors.text }]}>Total TTC</Text>
            <Text style={[styles.totalValue, { color: colors.primary }]}>{totalTTC.toFixed(2)} €</Text>
          </View>
        </CardContent>
      </Card>

      {quote.validUntil && (
        <View style={[styles.validUntil, { backgroundColor: colors.warning + '20' }]}>
          <Ionicons name="time-outline" size={18} color={colors.warning} />
          <Text style={[styles.validUntilText, { color: colors.warning }]}>
            Valide jusqu'au {format(new Date(quote.validUntil), "d MMMM yyyy", { locale: fr })}
          </Text>
        </View>
      )}

      {quote.status === 'pending' && !isAdmin && (
        <View style={styles.actions}>
          <Button 
            onPress={handleApprove} 
            loading={updateStatusMutation.isPending}
            style={styles.actionButton}
          >
            Accepter le devis
          </Button>
          <Button 
            variant="destructive" 
            onPress={handleReject}
            loading={updateStatusMutation.isPending}
            style={styles.actionButton}
          >
            Refuser le devis
          </Button>
        </View>
      )}

      {quote.status === 'approved' && isAdmin && (
        <View style={styles.actions}>
          <Button 
            onPress={handleGenerateInvoice} 
            loading={generateInvoiceMutation.isPending}
            style={styles.actionButton}
          >
            Générer une facture
          </Button>
        </View>
      )}

      <View style={styles.bottomPadding} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  center: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    padding: 20,
  },
  reference: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  date: {
    fontSize: 14,
    marginTop: 4,
  },
  section: {
    marginHorizontal: 16,
    marginBottom: 16,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 8,
  },
  infoText: {
    fontSize: 15,
  },
  serviceName: {
    fontSize: 16,
    fontWeight: '600',
  },
  serviceDesc: {
    fontSize: 14,
    marginTop: 4,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.05)',
  },
  detailLabel: {
    fontSize: 14,
  },
  detailValue: {
    fontSize: 14,
    fontWeight: '500',
  },
  notesBox: {
    marginTop: 12,
    padding: 12,
    borderRadius: 8,
  },
  notesLabel: {
    fontSize: 12,
    marginBottom: 4,
  },
  notesText: {
    fontSize: 14,
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
  },
  priceLabel: {
    fontSize: 14,
  },
  priceValue: {
    fontSize: 14,
    fontWeight: '500',
  },
  totalRow: {
    borderTopWidth: 1,
    marginTop: 8,
    paddingTop: 12,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: '600',
  },
  totalValue: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  validUntil: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginHorizontal: 16,
    padding: 12,
    borderRadius: 8,
  },
  validUntilText: {
    fontSize: 14,
    fontWeight: '500',
  },
  actions: {
    padding: 16,
    gap: 12,
  },
  actionButton: {
    marginBottom: 0,
  },
  bottomPadding: {
    height: 32,
  },
});
