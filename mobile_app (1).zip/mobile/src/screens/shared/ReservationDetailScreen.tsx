import { View, Text, StyleSheet, ScrollView, RefreshControl, Alert } from 'react-native';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/Card';
import { StatusBadge } from '@/components/Badge';
import { Button } from '@/components/Button';
import { LoadingScreen } from '@/components/LoadingScreen';
import { Ionicons } from '@expo/vector-icons';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { apiRequest } from '@/lib/api';
import type { Reservation } from '@/types/schema';
import { useState } from 'react';

export function ReservationDetailScreen({ route, navigation }: any) {
  const { id } = route.params;
  const { colors } = useTheme();
  const { isAdmin } = useAuth();
  const queryClient = useQueryClient();
  const [refreshing, setRefreshing] = useState(false);

  const { data: reservation, isLoading, refetch } = useQuery<Reservation>({
    queryKey: ['/api/reservations', id],
    queryFn: () => apiRequest('GET', `/api/reservations/${id}`),
  });

  const updateStatusMutation = useMutation({
    mutationFn: (status: string) => 
      apiRequest('PATCH', isAdmin ? `/api/admin/reservations/${id}` : `/api/reservations/${id}`, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/reservations'] });
      queryClient.invalidateQueries({ queryKey: ['/api/reservations', id] });
      Alert.alert('Succès', 'La réservation a été mise à jour');
    },
    onError: (error: Error) => {
      Alert.alert('Erreur', error.message);
    },
  });

  const onRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  };

  const handleConfirm = () => {
    Alert.alert(
      'Confirmer la réservation',
      'Voulez-vous confirmer cette réservation ?',
      [
        { text: 'Annuler', style: 'cancel' },
        { text: 'Confirmer', onPress: () => updateStatusMutation.mutate('confirmed') },
      ]
    );
  };

  const handleCancel = () => {
    Alert.alert(
      'Annuler la réservation',
      'Voulez-vous vraiment annuler cette réservation ?',
      [
        { text: 'Non', style: 'cancel' },
        { text: 'Oui, annuler', style: 'destructive', onPress: () => updateStatusMutation.mutate('cancelled') },
      ]
    );
  };

  const handleComplete = () => {
    Alert.alert(
      'Terminer la réservation',
      'Marquer cette réservation comme terminée ?',
      [
        { text: 'Annuler', style: 'cancel' },
        { text: 'Terminer', onPress: () => updateStatusMutation.mutate('completed') },
      ]
    );
  };

  if (isLoading) {
    return <LoadingScreen message="Chargement de la réservation..." />;
  }

  if (!reservation) {
    return (
      <View style={[styles.container, styles.center, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.textSecondary }}>Réservation non trouvée</Text>
      </View>
    );
  }

  const scheduledDate = new Date(reservation.scheduledDate);

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
      }
    >
      <View style={styles.header}>
        <View style={styles.dateTimeBox}>
          <View style={[styles.dateBadge, { backgroundColor: colors.primary }]}>
            <Text style={styles.dateDay}>{format(scheduledDate, 'dd')}</Text>
            <Text style={styles.dateMonth}>{format(scheduledDate, 'MMM', { locale: fr })}</Text>
          </View>
          <View style={styles.timeInfo}>
            <Text style={[styles.timeText, { color: colors.text }]}>
              {format(scheduledDate, 'HH:mm')}
            </Text>
            <Text style={[styles.dateFullText, { color: colors.textSecondary }]}>
              {format(scheduledDate, "EEEE d MMMM yyyy", { locale: fr })}
            </Text>
          </View>
        </View>
        <StatusBadge status={reservation.status} size="large" />
      </View>

      {reservation.service && (
        <Card style={styles.section}>
          <CardHeader>
            <CardTitle>Service</CardTitle>
          </CardHeader>
          <CardContent>
            <Text style={[styles.serviceName, { color: colors.text }]}>{reservation.service.name}</Text>
            {reservation.service.description && (
              <Text style={[styles.serviceDesc, { color: colors.textSecondary }]}>
                {reservation.service.description}
              </Text>
            )}
            {reservation.service.estimatedDuration && (
              <View style={styles.durationRow}>
                <Ionicons name="time-outline" size={16} color={colors.textSecondary} />
                <Text style={[styles.durationText, { color: colors.textSecondary }]}>
                  Durée estimée : {reservation.service.estimatedDuration} min
                </Text>
              </View>
            )}
          </CardContent>
        </Card>
      )}

      {reservation.client && (
        <Card style={styles.section}>
          <CardHeader>
            <CardTitle>Client</CardTitle>
          </CardHeader>
          <CardContent>
            <View style={styles.infoRow}>
              <Ionicons name="person-outline" size={18} color={colors.textSecondary} />
              <Text style={[styles.infoText, { color: colors.text }]}>
                {reservation.client.firstName} {reservation.client.lastName}
              </Text>
            </View>
            {reservation.client.email && (
              <View style={styles.infoRow}>
                <Ionicons name="mail-outline" size={18} color={colors.textSecondary} />
                <Text style={[styles.infoText, { color: colors.text }]}>{reservation.client.email}</Text>
              </View>
            )}
            {reservation.client.phone && (
              <View style={styles.infoRow}>
                <Ionicons name="call-outline" size={18} color={colors.textSecondary} />
                <Text style={[styles.infoText, { color: colors.text }]}>{reservation.client.phone}</Text>
              </View>
            )}
          </CardContent>
        </Card>
      )}

      <Card style={styles.section}>
        <CardHeader>
          <CardTitle>Détails</CardTitle>
        </CardHeader>
        <CardContent>
          {reservation.wheelCount && (
            <View style={styles.detailRow}>
              <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>Nombre de jantes</Text>
              <Text style={[styles.detailValue, { color: colors.text }]}>{reservation.wheelCount}</Text>
            </View>
          )}
          {reservation.diameter && (
            <View style={styles.detailRow}>
              <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>Diamètre</Text>
              <Text style={[styles.detailValue, { color: colors.text }]}>{reservation.diameter}"</Text>
            </View>
          )}
          {reservation.estimatedEndDate && (
            <View style={styles.detailRow}>
              <Text style={[styles.detailLabel, { color: colors.textSecondary }]}>Fin estimée</Text>
              <Text style={[styles.detailValue, { color: colors.text }]}>
                {format(new Date(reservation.estimatedEndDate), "d MMM yyyy HH:mm", { locale: fr })}
              </Text>
            </View>
          )}
          {reservation.notes && (
            <View style={[styles.notesBox, { backgroundColor: colors.muted }]}>
              <Text style={[styles.notesLabel, { color: colors.textSecondary }]}>Notes</Text>
              <Text style={[styles.notesText, { color: colors.text }]}>{reservation.notes}</Text>
            </View>
          )}
        </CardContent>
      </Card>

      {reservation.priceExcludingTax && (
        <Card style={styles.section}>
          <CardHeader>
            <CardTitle>Tarif</CardTitle>
          </CardHeader>
          <CardContent>
            <View style={styles.priceRow}>
              <Text style={[styles.priceLabel, { color: colors.textSecondary }]}>Prix HT</Text>
              <Text style={[styles.priceValue, { color: colors.text }]}>
                {parseFloat(reservation.priceExcludingTax).toFixed(2)} €
              </Text>
            </View>
            {reservation.taxAmount && (
              <View style={styles.priceRow}>
                <Text style={[styles.priceLabel, { color: colors.textSecondary }]}>TVA</Text>
                <Text style={[styles.priceValue, { color: colors.text }]}>
                  {parseFloat(reservation.taxAmount).toFixed(2)} €
                </Text>
              </View>
            )}
          </CardContent>
        </Card>
      )}

      <View style={styles.actions}>
        {reservation.status === 'pending' && isAdmin && (
          <Button 
            onPress={handleConfirm} 
            loading={updateStatusMutation.isPending}
            style={styles.actionButton}
          >
            Confirmer la réservation
          </Button>
        )}

        {reservation.status === 'confirmed' && isAdmin && (
          <Button 
            onPress={handleComplete} 
            loading={updateStatusMutation.isPending}
            style={styles.actionButton}
          >
            Marquer comme terminée
          </Button>
        )}

        {(reservation.status === 'pending' || reservation.status === 'confirmed') && (
          <Button 
            variant="destructive" 
            onPress={handleCancel}
            loading={updateStatusMutation.isPending}
            style={styles.actionButton}
          >
            Annuler la réservation
          </Button>
        )}
      </View>

      <View style={styles.bottomPadding} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  center: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    padding: 20,
  },
  dateTimeBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  dateBadge: {
    width: 60,
    height: 60,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dateDay: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  dateMonth: {
    fontSize: 12,
    color: '#fff',
    textTransform: 'uppercase',
  },
  timeInfo: {},
  timeText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  dateFullText: {
    fontSize: 14,
    marginTop: 2,
  },
  section: {
    marginHorizontal: 16,
    marginBottom: 16,
  },
  serviceName: {
    fontSize: 16,
    fontWeight: '600',
  },
  serviceDesc: {
    fontSize: 14,
    marginTop: 4,
  },
  durationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 8,
  },
  durationText: {
    fontSize: 13,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 8,
  },
  infoText: {
    fontSize: 15,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.05)',
  },
  detailLabel: {
    fontSize: 14,
  },
  detailValue: {
    fontSize: 14,
    fontWeight: '500',
  },
  notesBox: {
    marginTop: 12,
    padding: 12,
    borderRadius: 8,
  },
  notesLabel: {
    fontSize: 12,
    marginBottom: 4,
  },
  notesText: {
    fontSize: 14,
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
  },
  priceLabel: {
    fontSize: 14,
  },
  priceValue: {
    fontSize: 14,
    fontWeight: '500',
  },
  actions: {
    padding: 16,
    gap: 12,
  },
  actionButton: {
    marginBottom: 0,
  },
  bottomPadding: {
    height: 32,
  },
});
