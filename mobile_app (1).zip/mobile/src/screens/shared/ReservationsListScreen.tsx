import { View, Text, StyleSheet, FlatList, RefreshControl, TouchableOpacity } from 'react-native';
import { useQuery } from '@tanstack/react-query';
import { useTheme } from '@/contexts/ThemeContext';
import { StatusBadge } from '@/components/Badge';
import { LoadingScreen } from '@/components/LoadingScreen';
import { Ionicons } from '@expo/vector-icons';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import type { Reservation } from '@/types/schema';
import { useState } from 'react';

export function ReservationsListScreen({ navigation }: any) {
  const { colors } = useTheme();
  const [refreshing, setRefreshing] = useState(false);

  const { data: reservations, isLoading, refetch } = useQuery<Reservation[]>({
    queryKey: ['/api/reservations'],
  });

  const onRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  };

  if (isLoading) {
    return <LoadingScreen message="Chargement des réservations..." />;
  }

  const renderItem = ({ item }: { item: Reservation }) => {
    const scheduledDate = new Date(item.scheduledDate);
    
    return (
      <TouchableOpacity
        style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}
        onPress={() => navigation.navigate('ReservationDetail', { id: item.id })}
      >
        <View style={styles.cardHeader}>
          <View style={styles.dateBox}>
            <Text style={[styles.dateDay, { color: colors.primary }]}>
              {format(scheduledDate, 'dd')}
            </Text>
            <Text style={[styles.dateMonth, { color: colors.textSecondary }]}>
              {format(scheduledDate, 'MMM', { locale: fr })}
            </Text>
          </View>
          <View style={styles.headerInfo}>
            <Text style={[styles.serviceName, { color: colors.text }]}>
              {item.service?.name || 'Service'}
            </Text>
            <Text style={[styles.time, { color: colors.textSecondary }]}>
              {format(scheduledDate, 'HH:mm')}
            </Text>
          </View>
          <StatusBadge status={item.status} />
        </View>
        
        <View style={styles.cardContent}>
          {item.client && (
            <View style={styles.infoRow}>
              <Ionicons name="person-outline" size={16} color={colors.textSecondary} />
              <Text style={[styles.infoText, { color: colors.textSecondary }]}>
                {item.client.firstName} {item.client.lastName}
              </Text>
            </View>
          )}
          
          {item.wheelCount && (
            <View style={styles.infoRow}>
              <Ionicons name="disc-outline" size={16} color={colors.textSecondary} />
              <Text style={[styles.infoText, { color: colors.textSecondary }]}>
                {item.wheelCount} jante(s) - {item.diameter}"
              </Text>
            </View>
          )}

          {item.notes && (
            <View style={styles.notes}>
              <Text style={[styles.notesText, { color: colors.textTertiary }]} numberOfLines={2}>
                {item.notes}
              </Text>
            </View>
          )}
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <FlatList
        data={reservations}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
        }
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="calendar-outline" size={48} color={colors.textTertiary} />
            <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
              Aucune réservation
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  list: {
    padding: 16,
    gap: 12,
  },
  card: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 16,
    marginBottom: 12,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 12,
  },
  dateBox: {
    width: 50,
    alignItems: 'center',
  },
  dateDay: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  dateMonth: {
    fontSize: 12,
    textTransform: 'uppercase',
  },
  headerInfo: {
    flex: 1,
  },
  serviceName: {
    fontSize: 16,
    fontWeight: '600',
  },
  time: {
    fontSize: 14,
    marginTop: 2,
  },
  cardContent: {},
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 6,
  },
  infoText: {
    fontSize: 14,
  },
  notes: {
    marginTop: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: 'rgba(0,0,0,0.05)',
  },
  notesText: {
    fontSize: 13,
    fontStyle: 'italic',
  },
  empty: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 16,
    marginTop: 12,
  },
});
