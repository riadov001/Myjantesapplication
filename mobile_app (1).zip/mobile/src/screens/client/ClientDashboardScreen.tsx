import { View, Text, StyleSheet, ScrollView, RefreshControl, TouchableOpacity } from 'react-native';
import { useQuery } from '@tanstack/react-query';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/Card';
import { StatusBadge } from '@/components/Badge';
import { LoadingScreen } from '@/components/LoadingScreen';
import { Ionicons } from '@expo/vector-icons';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';
import type { Quote, Invoice, Reservation } from '@/types/schema';
import { useState } from 'react';

export function ClientDashboardScreen({ navigation }: any) {
  const { colors } = useTheme();
  const { user } = useAuth();
  const [refreshing, setRefreshing] = useState(false);

  const { data: quotes, isLoading: quotesLoading, refetch: refetchQuotes } = useQuery<Quote[]>({
    queryKey: ['/api/quotes'],
  });

  const { data: invoices, isLoading: invoicesLoading, refetch: refetchInvoices } = useQuery<Invoice[]>({
    queryKey: ['/api/invoices'],
  });

  const { data: reservations, isLoading: reservationsLoading, refetch: refetchReservations } = useQuery<Reservation[]>({
    queryKey: ['/api/reservations'],
  });

  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([refetchQuotes(), refetchInvoices(), refetchReservations()]);
    setRefreshing(false);
  };

  if (quotesLoading || invoicesLoading || reservationsLoading) {
    return <LoadingScreen message="Chargement..." />;
  }

  const recentQuotes = quotes?.slice(0, 3) || [];
  const pendingInvoices = invoices?.filter(i => i.status === 'pending').slice(0, 3) || [];
  const upcomingReservations = reservations
    ?.filter(r => r.status === 'confirmed' || r.status === 'pending')
    .slice(0, 3) || [];

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
      }
    >
      <View style={styles.header}>
        <Text style={[styles.greeting, { color: colors.text }]}>
          Bonjour, {user?.firstName || 'Client'}
        </Text>
        <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
          Bienvenue sur votre espace
        </Text>
      </View>

      <View style={styles.statsContainer}>
        <TouchableOpacity
          style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}
          onPress={() => navigation.navigate('Quotes')}
        >
          <Ionicons name="document-text-outline" size={24} color={colors.primary} />
          <Text style={[styles.statValue, { color: colors.text }]}>{quotes?.length || 0}</Text>
          <Text style={[styles.statLabel, { color: colors.textSecondary }]}>Devis</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}
          onPress={() => navigation.navigate('Invoices')}
        >
          <Ionicons name="receipt-outline" size={24} color={colors.success} />
          <Text style={[styles.statValue, { color: colors.text }]}>{invoices?.length || 0}</Text>
          <Text style={[styles.statLabel, { color: colors.textSecondary }]}>Factures</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}
          onPress={() => navigation.navigate('Reservations')}
        >
          <Ionicons name="calendar-outline" size={24} color={colors.warning} />
          <Text style={[styles.statValue, { color: colors.text }]}>{reservations?.length || 0}</Text>
          <Text style={[styles.statLabel, { color: colors.textSecondary }]}>Réservations</Text>
        </TouchableOpacity>
      </View>

      <Card style={styles.section}>
        <CardHeader>
          <View style={styles.sectionHeader}>
            <CardTitle>Devis récents</CardTitle>
            <TouchableOpacity onPress={() => navigation.navigate('Quotes')}>
              <Text style={[styles.seeAll, { color: colors.primary }]}>Voir tout</Text>
            </TouchableOpacity>
          </View>
        </CardHeader>
        <CardContent>
          {recentQuotes.length === 0 ? (
            <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
              Aucun devis récent
            </Text>
          ) : (
            recentQuotes.map((quote) => (
              <TouchableOpacity
                key={quote.id}
                style={[styles.listItem, { borderBottomColor: colors.border }]}
                onPress={() => navigation.navigate('QuoteDetail', { id: quote.id })}
              >
                <View style={styles.listItemContent}>
                  <Text style={[styles.listItemTitle, { color: colors.text }]}>
                    {quote.reference || `Devis #${quote.id.slice(0, 8)}`}
                  </Text>
                  <Text style={[styles.listItemDate, { color: colors.textSecondary }]}>
                    {quote.createdAt
                      ? formatDistanceToNow(new Date(quote.createdAt), { addSuffix: true, locale: fr })
                      : ''}
                  </Text>
                </View>
                <StatusBadge status={quote.status} />
              </TouchableOpacity>
            ))
          )}
        </CardContent>
      </Card>

      <Card style={styles.section}>
        <CardHeader>
          <View style={styles.sectionHeader}>
            <CardTitle>Factures en attente</CardTitle>
            <TouchableOpacity onPress={() => navigation.navigate('Invoices')}>
              <Text style={[styles.seeAll, { color: colors.primary }]}>Voir tout</Text>
            </TouchableOpacity>
          </View>
        </CardHeader>
        <CardContent>
          {pendingInvoices.length === 0 ? (
            <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
              Aucune facture en attente
            </Text>
          ) : (
            pendingInvoices.map((invoice) => (
              <TouchableOpacity
                key={invoice.id}
                style={[styles.listItem, { borderBottomColor: colors.border }]}
                onPress={() => navigation.navigate('InvoiceDetail', { id: invoice.id })}
              >
                <View style={styles.listItemContent}>
                  <Text style={[styles.listItemTitle, { color: colors.text }]}>
                    {invoice.invoiceNumber}
                  </Text>
                  <Text style={[styles.listItemAmount, { color: colors.primary }]}>
                    {parseFloat(invoice.amount).toFixed(2)} €
                  </Text>
                </View>
                <StatusBadge status={invoice.status} />
              </TouchableOpacity>
            ))
          )}
        </CardContent>
      </Card>

      <Card style={[styles.section, styles.lastSection]}>
        <CardHeader>
          <View style={styles.sectionHeader}>
            <CardTitle>Prochains rendez-vous</CardTitle>
            <TouchableOpacity onPress={() => navigation.navigate('Reservations')}>
              <Text style={[styles.seeAll, { color: colors.primary }]}>Voir tout</Text>
            </TouchableOpacity>
          </View>
        </CardHeader>
        <CardContent>
          {upcomingReservations.length === 0 ? (
            <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
              Aucun rendez-vous à venir
            </Text>
          ) : (
            upcomingReservations.map((reservation) => (
              <TouchableOpacity
                key={reservation.id}
                style={[styles.listItem, { borderBottomColor: colors.border }]}
                onPress={() => navigation.navigate('ReservationDetail', { id: reservation.id })}
              >
                <View style={styles.listItemContent}>
                  <Text style={[styles.listItemTitle, { color: colors.text }]}>
                    {reservation.service?.name || 'Service'}
                  </Text>
                  <Text style={[styles.listItemDate, { color: colors.textSecondary }]}>
                    {new Date(reservation.scheduledDate).toLocaleDateString('fr-FR', {
                      weekday: 'long',
                      day: 'numeric',
                      month: 'long',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </Text>
                </View>
                <StatusBadge status={reservation.status} />
              </TouchableOpacity>
            ))
          )}
        </CardContent>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    padding: 20,
    paddingBottom: 10,
  },
  greeting: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: 16,
    marginTop: 4,
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    gap: 12,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    marginTop: 4,
  },
  section: {
    marginHorizontal: 16,
    marginBottom: 16,
  },
  lastSection: {
    marginBottom: 32,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  seeAll: {
    fontSize: 14,
    fontWeight: '500',
  },
  listItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  listItemContent: {
    flex: 1,
    marginRight: 12,
  },
  listItemTitle: {
    fontSize: 16,
    fontWeight: '500',
  },
  listItemDate: {
    fontSize: 12,
    marginTop: 4,
  },
  listItemAmount: {
    fontSize: 14,
    fontWeight: '600',
    marginTop: 4,
  },
  emptyText: {
    textAlign: 'center',
    paddingVertical: 20,
    fontSize: 14,
  },
});
