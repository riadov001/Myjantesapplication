import { View, Text, StyleSheet, FlatList, RefreshControl, TouchableOpacity, Alert, Switch } from 'react-native';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useTheme } from '@/contexts/ThemeContext';
import { LoadingScreen } from '@/components/LoadingScreen';
import { Ionicons } from '@expo/vector-icons';
import { apiRequest } from '@/lib/api';
import type { Service } from '@/types/schema';
import { useState } from 'react';

export function ServicesListScreen() {
  const { colors } = useTheme();
  const queryClient = useQueryClient();
  const [refreshing, setRefreshing] = useState(false);

  const { data: services, isLoading, refetch } = useQuery<Service[]>({
    queryKey: ['/api/services'],
  });

  const toggleActiveMutation = useMutation({
    mutationFn: ({ serviceId, isActive }: { serviceId: string; isActive: boolean }) =>
      apiRequest('PATCH', `/api/admin/services/${serviceId}`, { isActive }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/services'] });
    },
    onError: (error: Error) => {
      Alert.alert('Erreur', error.message);
    },
  });

  const deleteServiceMutation = useMutation({
    mutationFn: (serviceId: string) =>
      apiRequest('DELETE', `/api/admin/services/${serviceId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/services'] });
      Alert.alert('Succès', 'Le service a été supprimé');
    },
    onError: (error: Error) => {
      Alert.alert('Erreur', error.message);
    },
  });

  const onRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  };

  if (isLoading) {
    return <LoadingScreen message="Chargement des services..." />;
  }

  const handleDeleteService = (service: Service) => {
    Alert.alert(
      'Supprimer le service',
      `Voulez-vous vraiment supprimer "${service.name}" ?`,
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Supprimer',
          style: 'destructive',
          onPress: () => deleteServiceMutation.mutate(service.id),
        },
      ]
    );
  };

  const renderItem = ({ item }: { item: Service }) => (
    <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={styles.cardHeader}>
        <View style={styles.serviceInfo}>
          <Text style={[styles.serviceName, { color: colors.text }]}>{item.name}</Text>
          {item.category && (
            <View style={[styles.categoryBadge, { backgroundColor: colors.muted }]}>
              <Text style={[styles.categoryText, { color: colors.textSecondary }]}>
                {item.category}
              </Text>
            </View>
          )}
        </View>
        <Switch
          value={item.isActive}
          onValueChange={(value) =>
            toggleActiveMutation.mutate({ serviceId: item.id, isActive: value })
          }
          trackColor={{ false: colors.border, true: colors.primary + '60' }}
          thumbColor={item.isActive ? colors.primary : colors.textTertiary}
        />
      </View>

      {item.description && (
        <Text style={[styles.description, { color: colors.textSecondary }]} numberOfLines={2}>
          {item.description}
        </Text>
      )}

      <View style={styles.footer}>
        <View style={styles.details}>
          {item.basePrice && (
            <View style={styles.detailItem}>
              <Ionicons name="pricetag-outline" size={14} color={colors.primary} />
              <Text style={[styles.detailText, { color: colors.primary }]}>
                {parseFloat(item.basePrice).toFixed(0)} €
              </Text>
            </View>
          )}
          {item.estimatedDuration && (
            <View style={styles.detailItem}>
              <Ionicons name="time-outline" size={14} color={colors.textSecondary} />
              <Text style={[styles.detailText, { color: colors.textSecondary }]}>
                {item.estimatedDuration} min
              </Text>
            </View>
          )}
        </View>

        <TouchableOpacity
          onPress={() => handleDeleteService(item)}
          style={[styles.deleteButton, { backgroundColor: colors.destructive + '20' }]}
        >
          <Ionicons name="trash-outline" size={18} color={colors.destructive} />
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <FlatList
        data={services}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
        }
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="grid-outline" size={48} color={colors.textTertiary} />
            <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
              Aucun service
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  list: {
    padding: 16,
  },
  card: {
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 12,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  serviceInfo: {
    flex: 1,
    marginRight: 12,
  },
  serviceName: {
    fontSize: 16,
    fontWeight: '600',
  },
  categoryBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    marginTop: 6,
  },
  categoryText: {
    fontSize: 12,
  },
  description: {
    fontSize: 14,
    marginBottom: 12,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(0,0,0,0.05)',
  },
  details: {
    flexDirection: 'row',
    gap: 16,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  detailText: {
    fontSize: 14,
    fontWeight: '500',
  },
  deleteButton: {
    padding: 8,
    borderRadius: 8,
  },
  empty: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 16,
    marginTop: 12,
  },
});
