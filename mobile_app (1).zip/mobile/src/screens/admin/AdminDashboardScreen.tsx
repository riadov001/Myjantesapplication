import { View, Text, StyleSheet, ScrollView, RefreshControl, TouchableOpacity, Dimensions } from 'react-native';
import { useQuery } from '@tanstack/react-query';
import { useTheme } from '@/contexts/ThemeContext';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/Card';
import { LoadingScreen } from '@/components/LoadingScreen';
import { Ionicons } from '@expo/vector-icons';
import { format, subDays, startOfMonth, endOfMonth, isWithinInterval } from 'date-fns';
import { fr } from 'date-fns/locale';
import type { Quote, Invoice, Reservation, User } from '@/types/schema';
import { useState, useMemo } from 'react';

const { width: screenWidth } = Dimensions.get('window');

export function AdminDashboardScreen({ navigation }: any) {
  const { colors } = useTheme();
  const [refreshing, setRefreshing] = useState(false);

  const { data: quotes, isLoading: quotesLoading, refetch: refetchQuotes } = useQuery<Quote[]>({
    queryKey: ['/api/quotes'],
  });

  const { data: invoices, isLoading: invoicesLoading, refetch: refetchInvoices } = useQuery<Invoice[]>({
    queryKey: ['/api/invoices'],
  });

  const { data: reservations, isLoading: reservationsLoading, refetch: refetchReservations } = useQuery<Reservation[]>({
    queryKey: ['/api/reservations'],
  });

  const { data: users, isLoading: usersLoading, refetch: refetchUsers } = useQuery<User[]>({
    queryKey: ['/api/admin/users'],
  });

  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([refetchQuotes(), refetchInvoices(), refetchReservations(), refetchUsers()]);
    setRefreshing(false);
  };

  const analytics = useMemo(() => {
    const now = new Date();
    const currentMonthStart = startOfMonth(now);
    const currentMonthEnd = endOfMonth(now);

    const thisMonthInvoices = invoices?.filter(i => {
      if (!i.createdAt) return false;
      const date = new Date(i.createdAt);
      return isWithinInterval(date, { start: currentMonthStart, end: currentMonthEnd });
    }) || [];

    const paidThisMonth = thisMonthInvoices.filter(i => i.status === 'paid');
    const revenueThisMonth = paidThisMonth.reduce((sum, i) => sum + parseFloat(i.amount || '0'), 0);

    const quotesThisMonth = quotes?.filter(q => {
      if (!q.createdAt) return false;
      const date = new Date(q.createdAt);
      return isWithinInterval(date, { start: currentMonthStart, end: currentMonthEnd });
    }) || [];

    const reservationsThisMonth = reservations?.filter(r => {
      if (!r.createdAt) return false;
      const date = new Date(r.createdAt);
      return isWithinInterval(date, { start: currentMonthStart, end: currentMonthEnd });
    }) || [];

    const last7DaysRevenue: { day: string; amount: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const day = subDays(now, i);
      const dayStr = format(day, 'yyyy-MM-dd');
      const dayRevenue = invoices?.filter(inv => {
        if (!inv.paidAt || inv.status !== 'paid') return false;
        return format(new Date(inv.paidAt), 'yyyy-MM-dd') === dayStr;
      }).reduce((sum, inv) => sum + parseFloat(inv.amount || '0'), 0) || 0;

      last7DaysRevenue.push({
        day: format(day, 'EEE', { locale: fr }),
        amount: dayRevenue,
      });
    }

    const maxDayRevenue = Math.max(...last7DaysRevenue.map(d => d.amount), 1);

    return {
      revenueThisMonth,
      quotesThisMonth: quotesThisMonth.length,
      reservationsThisMonth: reservationsThisMonth.length,
      invoicesThisMonth: thisMonthInvoices.length,
      paidInvoicesThisMonth: paidThisMonth.length,
      overdueInvoices: invoices?.filter(i => i.status === 'overdue').length || 0,
      conversionRate: quotes?.length 
        ? ((invoices?.length || 0) / quotes.length * 100).toFixed(0)
        : '0',
      last7DaysRevenue,
      maxDayRevenue,
    };
  }, [quotes, invoices, reservations]);

  if (quotesLoading || invoicesLoading || reservationsLoading || usersLoading) {
    return <LoadingScreen message="Chargement..." />;
  }

  const pendingQuotes = quotes?.filter(q => q.status === 'pending').length || 0;
  const pendingReservations = reservations?.filter(r => r.status === 'pending').length || 0;
  const pendingInvoices = invoices?.filter(i => i.status === 'pending').length || 0;
  const totalRevenue = invoices
    ?.filter(i => i.status === 'paid')
    .reduce((sum, i) => sum + parseFloat(i.amount || '0'), 0) || 0;

  const quickActions = [
    { title: 'Prestations', icon: 'briefcase-outline' as const, route: 'Engagements', color: colors.primary },
    { title: 'Atelier', icon: 'construct-outline' as const, route: 'Workshop', color: colors.warning },
    { title: 'Devis', icon: 'document-text-outline' as const, route: 'Quotes', color: colors.success },
    { title: 'Factures', icon: 'receipt-outline' as const, route: 'Invoices', color: '#9333ea' },
    { title: 'Réservations', icon: 'calendar-outline' as const, route: 'Reservations', color: '#ec4899' },
    { title: 'Services', icon: 'grid-outline' as const, route: 'Services', color: '#14b8a6' },
    { title: 'Utilisateurs', icon: 'people-outline' as const, route: 'Users', color: '#f97316' },
    { title: 'Chat', icon: 'chatbubbles-outline' as const, route: 'Chat', color: '#8b5cf6' },
  ];

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
      }
    >
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.text }]}>Tableau de bord</Text>
        <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
          Vue d'ensemble de l'activité
        </Text>
      </View>

      <View style={styles.statsGrid}>
        <TouchableOpacity
          style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}
          onPress={() => navigation.navigate('Reservations')}
        >
          <View style={[styles.statIcon, { backgroundColor: colors.warning + '20' }]}>
            <Ionicons name="calendar" size={20} color={colors.warning} />
          </View>
          <Text style={[styles.statValue, { color: colors.text }]}>{pendingReservations}</Text>
          <Text style={[styles.statLabel, { color: colors.textSecondary }]}>RDV en attente</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}
          onPress={() => navigation.navigate('Quotes')}
        >
          <View style={[styles.statIcon, { backgroundColor: colors.primary + '20' }]}>
            <Ionicons name="document-text" size={20} color={colors.primary} />
          </View>
          <Text style={[styles.statValue, { color: colors.text }]}>{pendingQuotes}</Text>
          <Text style={[styles.statLabel, { color: colors.textSecondary }]}>Devis en attente</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}
          onPress={() => navigation.navigate('Invoices')}
        >
          <View style={[styles.statIcon, { backgroundColor: colors.destructive + '20' }]}>
            <Ionicons name="receipt" size={20} color={colors.destructive} />
          </View>
          <Text style={[styles.statValue, { color: colors.text }]}>{pendingInvoices}</Text>
          <Text style={[styles.statLabel, { color: colors.textSecondary }]}>Factures à payer</Text>
        </TouchableOpacity>

        <View style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.statIcon, { backgroundColor: colors.success + '20' }]}>
            <Ionicons name="cash" size={20} color={colors.success} />
          </View>
          <Text style={[styles.statValue, { color: colors.text }]}>{totalRevenue.toFixed(0)} €</Text>
          <Text style={[styles.statLabel, { color: colors.textSecondary }]}>Chiffre d'affaires</Text>
        </View>
      </View>

      <Card style={styles.section}>
        <CardHeader>
          <CardTitle>Actions rapides</CardTitle>
        </CardHeader>
        <CardContent>
          <View style={styles.actionsGrid}>
            {quickActions.map((action) => (
              <TouchableOpacity
                key={action.route}
                style={[styles.actionButton, { backgroundColor: colors.muted }]}
                onPress={() => navigation.navigate(action.route)}
              >
                <View style={[styles.actionIcon, { backgroundColor: action.color + '20' }]}>
                  <Ionicons name={action.icon} size={24} color={action.color} />
                </View>
                <Text style={[styles.actionLabel, { color: colors.text }]}>{action.title}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </CardContent>
      </Card>

      <Card style={styles.section}>
        <CardHeader>
          <CardTitle>Revenus - 7 derniers jours</CardTitle>
        </CardHeader>
        <CardContent>
          <View style={styles.chartContainer}>
            {analytics.last7DaysRevenue.map((data, index) => (
              <View key={index} style={styles.chartBar}>
                <View style={styles.barContainer}>
                  <View
                    style={[
                      styles.bar,
                      {
                        backgroundColor: colors.primary,
                        height: Math.max((data.amount / analytics.maxDayRevenue) * 80, 4),
                      },
                    ]}
                  />
                </View>
                <Text style={[styles.barLabel, { color: colors.textSecondary }]}>{data.day}</Text>
                <Text style={[styles.barValue, { color: colors.textTertiary }]}>
                  {data.amount > 0 ? `${data.amount.toFixed(0)}€` : '-'}
                </Text>
              </View>
            ))}
          </View>
        </CardContent>
      </Card>

      <Card style={styles.section}>
        <CardHeader>
          <CardTitle>Ce mois-ci</CardTitle>
        </CardHeader>
        <CardContent>
          <View style={styles.monthStats}>
            <View style={[styles.monthStatCard, { backgroundColor: colors.success + '15' }]}>
              <Text style={[styles.monthStatValue, { color: colors.success }]}>
                {analytics.revenueThisMonth.toFixed(0)} €
              </Text>
              <Text style={[styles.monthStatLabel, { color: colors.textSecondary }]}>CA du mois</Text>
            </View>
            <View style={[styles.monthStatCard, { backgroundColor: colors.primary + '15' }]}>
              <Text style={[styles.monthStatValue, { color: colors.primary }]}>
                {analytics.quotesThisMonth}
              </Text>
              <Text style={[styles.monthStatLabel, { color: colors.textSecondary }]}>Nouveaux devis</Text>
            </View>
            <View style={[styles.monthStatCard, { backgroundColor: colors.warning + '15' }]}>
              <Text style={[styles.monthStatValue, { color: colors.warning }]}>
                {analytics.reservationsThisMonth}
              </Text>
              <Text style={[styles.monthStatLabel, { color: colors.textSecondary }]}>Réservations</Text>
            </View>
          </View>
        </CardContent>
      </Card>

      <Card style={[styles.section, styles.lastSection]}>
        <CardHeader>
          <CardTitle>Statistiques globales</CardTitle>
        </CardHeader>
        <CardContent>
          <View style={styles.statsList}>
            <View style={[styles.statsRow, { borderBottomColor: colors.border }]}>
              <Text style={[styles.statsLabel, { color: colors.textSecondary }]}>Total devis</Text>
              <Text style={[styles.statsValue, { color: colors.text }]}>{quotes?.length || 0}</Text>
            </View>
            <View style={[styles.statsRow, { borderBottomColor: colors.border }]}>
              <Text style={[styles.statsLabel, { color: colors.textSecondary }]}>Total factures</Text>
              <Text style={[styles.statsValue, { color: colors.text }]}>{invoices?.length || 0}</Text>
            </View>
            <View style={[styles.statsRow, { borderBottomColor: colors.border }]}>
              <Text style={[styles.statsLabel, { color: colors.textSecondary }]}>Factures en retard</Text>
              <Text style={[styles.statsValue, { color: analytics.overdueInvoices > 0 ? colors.destructive : colors.text }]}>
                {analytics.overdueInvoices}
              </Text>
            </View>
            <View style={[styles.statsRow, { borderBottomColor: colors.border }]}>
              <Text style={[styles.statsLabel, { color: colors.textSecondary }]}>Taux de conversion</Text>
              <Text style={[styles.statsValue, { color: colors.success }]}>{analytics.conversionRate}%</Text>
            </View>
            <View style={[styles.statsRow, { borderBottomColor: colors.border }]}>
              <Text style={[styles.statsLabel, { color: colors.textSecondary }]}>Total réservations</Text>
              <Text style={[styles.statsValue, { color: colors.text }]}>{reservations?.length || 0}</Text>
            </View>
            <View style={styles.statsRow}>
              <Text style={[styles.statsLabel, { color: colors.textSecondary }]}>Utilisateurs</Text>
              <Text style={[styles.statsValue, { color: colors.text }]}>{users?.length || 0}</Text>
            </View>
          </View>
        </CardContent>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    padding: 20,
    paddingBottom: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: 16,
    marginTop: 4,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 12,
    gap: 12,
    marginBottom: 16,
  },
  statCard: {
    width: '47%',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
  },
  statIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  statLabel: {
    fontSize: 12,
    marginTop: 4,
  },
  section: {
    marginHorizontal: 16,
    marginBottom: 16,
  },
  lastSection: {
    marginBottom: 32,
  },
  actionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  actionButton: {
    width: '30%',
    padding: 12,
    borderRadius: 12,
    alignItems: 'center',
  },
  actionIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  actionLabel: {
    fontSize: 12,
    fontWeight: '500',
    textAlign: 'center',
  },
  statsList: {},
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  statsLabel: {
    fontSize: 14,
  },
  statsValue: {
    fontSize: 14,
    fontWeight: '600',
  },
  chartContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    height: 120,
    paddingTop: 8,
  },
  chartBar: {
    flex: 1,
    alignItems: 'center',
  },
  barContainer: {
    height: 80,
    justifyContent: 'flex-end',
    marginBottom: 6,
  },
  bar: {
    width: 24,
    borderRadius: 4,
    minHeight: 4,
  },
  barLabel: {
    fontSize: 10,
    textTransform: 'capitalize',
  },
  barValue: {
    fontSize: 9,
    marginTop: 2,
  },
  monthStats: {
    flexDirection: 'row',
    gap: 12,
  },
  monthStatCard: {
    flex: 1,
    padding: 12,
    borderRadius: 10,
    alignItems: 'center',
  },
  monthStatValue: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  monthStatLabel: {
    fontSize: 11,
    marginTop: 4,
    textAlign: 'center',
  },
});
