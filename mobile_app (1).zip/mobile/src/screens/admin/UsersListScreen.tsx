import { View, Text, StyleSheet, FlatList, RefreshControl, TouchableOpacity, Alert } from 'react-native';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useTheme } from '@/contexts/ThemeContext';
import { LoadingScreen } from '@/components/LoadingScreen';
import { Ionicons } from '@expo/vector-icons';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';
import { apiRequest } from '@/lib/api';
import type { User } from '@/types/schema';
import { useState } from 'react';

export function UsersListScreen() {
  const { colors } = useTheme();
  const queryClient = useQueryClient();
  const [refreshing, setRefreshing] = useState(false);

  const { data: users, isLoading, refetch } = useQuery<User[]>({
    queryKey: ['/api/admin/users'],
  });

  const updateRoleMutation = useMutation({
    mutationFn: ({ userId, role }: { userId: string; role: string }) =>
      apiRequest('PATCH', `/api/admin/users/${userId}`, { role }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
      Alert.alert('Succès', 'Le rôle a été mis à jour');
    },
    onError: (error: Error) => {
      Alert.alert('Erreur', error.message);
    },
  });

  const onRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  };

  if (isLoading) {
    return <LoadingScreen message="Chargement des utilisateurs..." />;
  }

  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'admin': return 'Administrateur';
      case 'superadmin': return 'Super Admin';
      case 'employe': return 'Employé';
      case 'client_professionnel': return 'Client Pro';
      case 'client': return 'Client';
      default: return role;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin':
      case 'superadmin': return colors.primary;
      case 'employe': return colors.warning;
      case 'client_professionnel': return '#8b5cf6';
      default: return colors.success;
    }
  };

  const handleChangeRole = (user: User) => {
    const roles = ['client', 'client_professionnel', 'employe', 'admin'];
    const buttons = roles.map(role => ({
      text: getRoleLabel(role),
      onPress: () => updateRoleMutation.mutate({ userId: user.id, role }),
    }));
    buttons.push({ text: 'Annuler', onPress: () => {} });

    Alert.alert(
      'Modifier le rôle',
      `Choisir un nouveau rôle pour ${user.firstName || user.email}`,
      buttons as any
    );
  };

  const renderItem = ({ item }: { item: User }) => (
    <TouchableOpacity
      style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}
      onPress={() => handleChangeRole(item)}
    >
      <View style={styles.avatar}>
        {item.profileImageUrl ? (
          <View style={[styles.avatarImage, { backgroundColor: colors.muted }]}>
            <Text style={[styles.avatarText, { color: colors.text }]}>
              {(item.firstName?.[0] || item.email[0]).toUpperCase()}
            </Text>
          </View>
        ) : (
          <View style={[styles.avatarImage, { backgroundColor: colors.muted }]}>
            <Text style={[styles.avatarText, { color: colors.text }]}>
              {(item.firstName?.[0] || item.email[0]).toUpperCase()}
            </Text>
          </View>
        )}
      </View>
      
      <View style={styles.content}>
        <Text style={[styles.name, { color: colors.text }]}>
          {item.firstName && item.lastName 
            ? `${item.firstName} ${item.lastName}` 
            : item.email}
        </Text>
        {item.firstName && (
          <Text style={[styles.email, { color: colors.textSecondary }]}>{item.email}</Text>
        )}
        {item.phone && (
          <View style={styles.infoRow}>
            <Ionicons name="call-outline" size={14} color={colors.textTertiary} />
            <Text style={[styles.infoText, { color: colors.textTertiary }]}>{item.phone}</Text>
          </View>
        )}
        {item.createdAt && (
          <Text style={[styles.date, { color: colors.textTertiary }]}>
            Inscrit {formatDistanceToNow(new Date(item.createdAt), { addSuffix: true, locale: fr })}
          </Text>
        )}
      </View>

      <View style={[styles.roleBadge, { backgroundColor: getRoleColor(item.role) + '20' }]}>
        <Text style={[styles.roleText, { color: getRoleColor(item.role) }]}>
          {getRoleLabel(item.role)}
        </Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <FlatList
        data={users}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
        }
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="people-outline" size={48} color={colors.textTertiary} />
            <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
              Aucun utilisateur
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  list: {
    padding: 16,
  },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 12,
    gap: 12,
  },
  avatar: {},
  avatarImage: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
  },
  name: {
    fontSize: 16,
    fontWeight: '600',
  },
  email: {
    fontSize: 14,
    marginTop: 2,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 4,
  },
  infoText: {
    fontSize: 12,
  },
  date: {
    fontSize: 11,
    marginTop: 4,
  },
  roleBadge: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
  },
  roleText: {
    fontSize: 11,
    fontWeight: '600',
  },
  empty: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 16,
    marginTop: 12,
  },
});
