export interface User {
  id: string;
  email: string;
  firstName?: string | null;
  lastName?: string | null;
  phone?: string | null;
  address?: string | null;
  postalCode?: string | null;
  city?: string | null;
  profileImageUrl?: string | null;
  role: 'client' | 'client_professionnel' | 'employe' | 'admin';
  companyName?: string | null;
  siret?: string | null;
  tvaNumber?: string | null;
  companyAddress?: string | null;
  createdAt?: string | null;
  updatedAt?: string | null;
}

export interface Service {
  id: string;
  name: string;
  description?: string | null;
  basePrice?: string | null;
  category?: string | null;
  isActive: boolean;
  estimatedDuration?: number | null;
  imageUrl?: string | null;
  customFormFields?: unknown;
  createdAt?: string | null;
  updatedAt?: string | null;
}

export interface Quote {
  id: string;
  reference?: string | null;
  clientId: string;
  serviceId: string;
  status: 'pending' | 'approved' | 'rejected' | 'completed';
  requestDetails?: unknown;
  quoteAmount?: string | null;
  wheelCount?: number | null;
  diameter?: string | null;
  priceExcludingTax?: string | null;
  taxRate?: string | null;
  taxAmount?: string | null;
  productDetails?: string | null;
  notes?: string | null;
  validUntil?: string | null;
  createdAt?: string | null;
  updatedAt?: string | null;
  client?: User;
  service?: Service;
}

export interface Invoice {
  id: string;
  quoteId?: string | null;
  clientId: string;
  invoiceNumber: string;
  amount: string;
  paymentMethod: 'cash' | 'wire_transfer' | 'card';
  wheelCount?: number | null;
  diameter?: string | null;
  priceExcludingTax?: string | null;
  taxRate?: string | null;
  taxAmount?: string | null;
  productDetails?: string | null;
  status: 'pending' | 'paid' | 'overdue' | 'cancelled';
  dueDate?: string | null;
  paidAt?: string | null;
  notes?: string | null;
  createdAt?: string | null;
  updatedAt?: string | null;
  client?: User;
}

export interface Reservation {
  id: string;
  quoteId?: string | null;
  clientId: string;
  serviceId: string;
  assignedEmployeeId?: string | null;
  scheduledDate: string;
  estimatedEndDate?: string | null;
  wheelCount?: number | null;
  diameter?: string | null;
  priceExcludingTax?: string | null;
  taxRate?: string | null;
  taxAmount?: string | null;
  productDetails?: string | null;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  notes?: string | null;
  createdAt?: string | null;
  updatedAt?: string | null;
  client?: User;
  service?: Service;
}

export interface Notification {
  id: string;
  userId: string;
  type: 'quote' | 'invoice' | 'reservation' | 'service' | 'chat';
  title: string;
  message: string;
  relatedId?: string | null;
  isRead: boolean;
  createdAt?: string | null;
}

export interface ChatConversation {
  id: string;
  title: string;
  createdById: string;
  isArchived: boolean;
  lastMessageAt?: string | null;
  createdAt?: string | null;
  updatedAt?: string | null;
  participants?: ChatParticipant[];
  unreadCount?: number;
}

export interface ChatParticipant {
  id: string;
  conversationId: string;
  userId: string;
  lastReadAt?: string | null;
  createdAt?: string | null;
  user?: User;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  content: string;
  isEdited: boolean;
  createdAt?: string | null;
  updatedAt?: string | null;
  sender?: User;
}

export interface ApplicationSettings {
  id: string;
  defaultWheelCount: number;
  defaultDiameter: string;
  defaultTaxRate: string;
  wheelCountOptions: string;
  diameterOptions: string;
  companyName: string;
  companyTagline?: string | null;
  companyAddress?: string | null;
  companyCity?: string | null;
  companyPhone?: string | null;
  companyEmail?: string | null;
  companyWebsite?: string | null;
  companySiret?: string | null;
  companyTvaNumber?: string | null;
  companyIban?: string | null;
  companySwift?: string | null;
  companyLogo?: string | null;
}
