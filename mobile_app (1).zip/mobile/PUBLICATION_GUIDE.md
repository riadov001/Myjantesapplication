# Guide de Publication MyJantes Mobile

Ce guide vous explique comment publier l'application MyJantes sur l'App Store (iOS) et le Play Store (Android).

## Prérequis

### Comptes développeur requis

| Plateforme | Coût | Lien |
|------------|------|------|
| Apple Developer | 99 €/an | [developer.apple.com](https://developer.apple.com/programs/) |
| Google Play Console | 25 € (une fois) | [play.google.com/console](https://play.google.com/console) |
| Expo (EAS) | Gratuit (builds limités) | [expo.dev](https://expo.dev) |

### Équipement

- **Pour iOS** : Un Mac avec Xcode installé (optionnel si vous utilisez EAS Build)
- **Pour Android** : Aucun équipement spécifique requis

---

## Étape 1 : Créer un compte Expo

1. Allez sur [expo.dev](https://expo.dev)
2. Créez un compte gratuit
3. Installez EAS CLI sur votre ordinateur :

```bash
npm install -g eas-cli
eas login
```

---

## Étape 2 : Configurer le projet

### 2.1 Télécharger le dossier mobile

Téléchargez le dossier `mobile/` de votre projet Replit sur votre ordinateur.

### 2.2 Mettre à jour app.json

Modifiez ces valeurs dans `mobile/app.json` :

```json
{
  "expo": {
    "owner": "votre-nom-utilisateur-expo",
    "extra": {
      "eas": {
        "projectId": "sera-généré-automatiquement"
      }
    }
  }
}
```

### 2.3 Initialiser EAS

Dans le dossier mobile, exécutez :

```bash
cd mobile
npm install
eas init
```

Cela va créer automatiquement votre `projectId`.

---

## Étape 3 : Assets graphiques (DÉJÀ CRÉÉS)

Les assets suivants ont été générés et sont prêts à l'emploi :

### Icône de l'application
- **Fichier** : `mobile/assets/icon.png`
- **Taille** : 1024 x 1024 pixels
- **Format** : PNG

### Écran de démarrage (Splash)
- **Fichier** : `mobile/assets/splash.png`
- **Format** : PNG vertical

### Captures d'écran pour les stores

**App Store (iOS)** - 4 captures disponibles :
- `mobile/assets/screenshots/ios/screenshot_dashboard_65.png`
- `mobile/assets/screenshots/ios/screenshot_quotes_65.png`
- `mobile/assets/screenshots/ios/screenshot_invoices_65.png`
- `mobile/assets/screenshots/ios/screenshot_notifications_65.png`

**Play Store (Android)** - 3 captures disponibles :
- `mobile/assets/screenshots/android/screenshot_dashboard.png`
- `mobile/assets/screenshots/android/screenshot_quotes.png`
- `mobile/assets/screenshots/android/screenshot_invoices.png`

---

## Étape 4 : Compiler l'application

### 4.1 Build de preview (test interne)

Pour tester avant publication :

```bash
# Android - génère un APK
eas build --platform android --profile preview

# iOS - pour TestFlight
eas build --platform ios --profile preview
```

### 4.2 Build de production

```bash
# Android - génère un AAB pour le Play Store
eas build --platform android --profile production

# iOS - pour l'App Store
eas build --platform ios --profile production
```

**Note** : Le premier build iOS vous demandera de vous connecter à votre compte Apple Developer.

---

## Étape 5 : Publication sur les stores

### 5.1 Google Play Store

1. **Créer l'application** dans Google Play Console
2. **Remplir les informations** :
   - Nom : MyJantes
   - Description courte et longue
   - Catégorie : Automobile ou Business
   - Politique de confidentialité (URL requise)
3. **Télécharger le fichier AAB** depuis EAS
4. **Configurer le prix** (gratuit ou payant)
5. **Soumettre pour examen** (1-3 jours)

Ou automatiquement avec EAS Submit :

```bash
eas submit --platform android --latest
```

### 5.2 Apple App Store

1. **Créer l'application** dans App Store Connect
2. **Remplir les informations** :
   - Nom : MyJantes
   - Sous-titre
   - Description
   - Mots-clés
   - Catégorie : Automobile ou Business
   - Captures d'écran
   - Politique de confidentialité (URL requise)
3. **Télécharger le build** depuis EAS
4. **Soumettre pour examen** (1-7 jours)

Ou automatiquement :

```bash
eas submit --platform ios --latest
```

---

## Étape 6 : Documents légaux requis

### Politique de confidentialité

Créez une page sur votre site web expliquant :
- Quelles données sont collectées
- Comment elles sont utilisées
- Comment les utilisateurs peuvent supprimer leurs données

**URL exemple** : `https://workspace-appmytools.replit.app/privacy`

### Conditions d'utilisation

Décrivez les règles d'utilisation de l'application.

---

## Coûts récapitulatifs

| Élément | Coût |
|---------|------|
| Apple Developer | 99 €/an |
| Google Play | 25 € (une fois) |
| EAS Build (gratuit) | 30 builds/mois |
| EAS Build (payant) | À partir de 15$/mois pour plus de builds |

---

## Commandes utiles

```bash
# Vérifier la configuration
eas build:configure

# Voir les builds en cours
eas build:list

# Télécharger un build
eas build:download

# Mettre à jour l'app sans rebuild (updates OTA)
eas update --branch production --message "Correction de bugs"
```

---

## Checklist avant publication

- [x] Icône de l'app (1024x1024)
- [x] Écran splash
- [x] 3+ captures d'écran par plateforme
- [ ] Description courte et longue
- [ ] Politique de confidentialité (URL)
- [ ] Compte Apple Developer actif
- [ ] Compte Google Play Console actif
- [ ] Build de production réussi
- [ ] Test sur appareil réel

---

## Support

Pour toute question sur la publication :
- [Documentation Expo](https://docs.expo.dev/submit/introduction/)
- [Guide App Store](https://developer.apple.com/app-store/submitting/)
- [Guide Play Store](https://support.google.com/googleplay/android-developer/answer/9859152)
